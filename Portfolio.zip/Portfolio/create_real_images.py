import base64
from PIL import Image, ImageDraw, ImageFont
import os

def create_project_image(filename, colors, icon_text, title, subtitle, features):
    # Create image
    img = Image.new('RGB', (400, 300), colors[0])
    draw = ImageDraw.Draw(img)
    
    # Create gradient effect
    for y in range(300):
        ratio = y / 300
        r = int(colors[0][0] * (1 - ratio) + colors[1][0] * ratio)
        g = int(colors[0][1] * (1 - ratio) + colors[1][1] * ratio)
        b = int(colors[0][2] * (1 - ratio) + colors[1][2] * ratio)
        draw.line([(0, y), (400, y)], fill=(r, g, b))
    
    # Add semi-transparent overlay
    overlay = Image.new('RGBA', (400, 300), (255, 255, 255, 30))
    img.paste(overlay, (0, 0), overlay)
    
    # Draw icon (using text since we can't use emoji easily)
    try:
        font_large = ImageFont.truetype("arial.ttf", 60)
        font_title = ImageFont.truetype("arial.ttf", 28)
        font_subtitle = ImageFont.truetype("arial.ttf", 20)
        font_features = ImageFont.truetype("arial.ttf", 16)
    except:
        font_large = ImageFont.load_default()
        font_title = ImageFont.load_default()
        font_subtitle = ImageFont.load_default()
        font_features = ImageFont.load_default()
    
    # Draw icon placeholder
    icon_map = {'👑': 'CROWN', '🏥': 'MED', '🧮': 'CALC'}
    icon_placeholder = icon_map.get(icon_text, icon_text)
    draw.text((200, 60), icon_placeholder, fill='white', font=font_large, anchor='mm')
    
    # Draw title
    draw.text((200, 130), title, fill='white', font=font_title, anchor='mm')
    
    # Draw subtitle
    draw.text((200, 160), subtitle, fill='white', font=font_subtitle, anchor='mm')
    
    # Draw features
    for i, feature in enumerate(features):
        draw.text((200, 200 + i * 25), f"• {feature}", fill='white', font=font_features, anchor='mm')
    
    # Save image
    os.makedirs('images', exist_ok=True)
    img.save(f'images/{filename}')
    print(f"Created: {filename}")

# Create images
create_project_image(
    'royal-cafe-preview.png',
    [(255, 215, 0), (255, 165, 0)],  # Gold to orange
    '👑',
    'Royal Cafe',
    'القائمة الملكية',
    ['قائمة كافيه احترافية', 'تصميم ملكي فاخر', 'نظام فلترة متقدم']
)

create_project_image(
    'medvibe-preview.png',
    [(102, 126, 234), (118, 75, 162)],  # Blue to purple
    '🏥',
    'MedVibe',
    'النظام الطبي المتكامل',
    ['حجز مواعيد ذكي', 'لوحة تحكم متقدمة', 'إدارة الأطباء والمرضى']
)

create_project_image(
    'calculator-preview.png',
    [(76, 175, 80), (69, 160, 73)],  # Green colors
    '🧮',
    'آلة حاسبة ذكية',
    'Calculator App',
    ['عمليات حسابية أساسية', 'عمليات علمية متقدمة', 'سجل العمليات السابقة']
)

print("All images created successfully!")
