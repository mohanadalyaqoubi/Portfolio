class CuteCalculator {
    constructor() {
        this.display = document.getElementById('display');
        this.historyDisplay = document.getElementById('history');
        this.historyList = document.getElementById('history-list');
        this.historyPanel = document.getElementById('history-panel');
        this.scientificPanel = document.getElementById('scientific-panel');
        this.overlay = document.getElementById('overlay');
        
        // Toggle buttons
        this.historyToggle = document.getElementById('history-toggle');
        this.scientificToggle = document.getElementById('scientific-toggle');
        this.closeHistory = document.getElementById('close-history');
        this.closeScientific = document.getElementById('close-scientific');
        this.clearHistoryBtn = document.getElementById('clear-history');
        
        this.currentValue = '0';
        this.previousValue = '';
        this.operation = null;
        this.shouldResetDisplay = false;
        this.history = [];
        this.isHistoryOpen = false;
        this.isScientificOpen = false;
        
        this.initializeEventListeners();
        this.loadHistory();
    }
    
    initializeEventListeners() {
        // Number buttons
        document.querySelectorAll('.btn-number').forEach(btn => {
            btn.addEventListener('click', () => {
                const number = btn.dataset.number;
                this.appendNumber(number);
            });
        });
        
        // Operator buttons
        document.querySelectorAll('.btn-operator').forEach(btn => {
            btn.addEventListener('click', () => {
                const operator = btn.dataset.operator;
                this.handleOperator(operator);
            });
        });
        
        // Function buttons
        document.querySelectorAll('.btn-function').forEach(btn => {
            btn.addEventListener('click', () => {
                const action = btn.dataset.action;
                this.handleFunction(action);
            });
        });
        
        // Equals button
        document.querySelector('.btn-equals').addEventListener('click', () => {
            this.calculate();
        });
        
        // Scientific buttons
        document.querySelectorAll('.btn-scientific').forEach(btn => {
            btn.addEventListener('click', () => {
                const func = btn.dataset.function;
                this.handleScientific(func);
            });
        });
        
        // Panel toggles
        this.historyToggle.addEventListener('click', () => {
            this.toggleHistory();
        });
        
        this.scientificToggle.addEventListener('click', () => {
            this.toggleScientific();
        });
        
        // Close buttons
        this.closeHistory.addEventListener('click', () => {
            this.closeHistoryPanel();
        });
        
        this.closeScientific.addEventListener('click', () => {
            this.closeScientificPanel();
        });
        
        // Clear history
        this.clearHistoryBtn.addEventListener('click', () => {
            this.clearHistory();
        });
        
        // History item clicks
        this.historyList.addEventListener('click', (e) => {
            const item = e.target.closest('.history-item');
            if (item) {
                this.useHistoryItem(item);
            }
        });
        
        // Overlay click
        this.overlay.addEventListener('click', () => {
            this.closeAllPanels();
        });
        
        // Keyboard support
        document.addEventListener('keydown', (e) => {
            this.handleKeyboard(e);
        });
        
        // Close panels when clicking outside
        document.addEventListener('click', (e) => {
            if (!this.historyPanel.contains(e.target) && 
                !this.historyToggle.contains(e.target) &&
                !this.scientificPanel.contains(e.target) && 
                !this.scientificToggle.contains(e.target)) {
                this.closeAllPanels();
            }
        });
    }
    
    appendNumber(number) {
        if (this.shouldResetDisplay) {
            this.currentValue = '0';
            this.shouldResetDisplay = false;
        }
        
        if (this.currentValue === '0' && number !== '.') {
            this.currentValue = number;
        } else if (number === '.' && !this.currentValue.includes('.')) {
            this.currentValue += number;
        } else if (number !== '.') {
            this.currentValue += number;
        }
        
        this.updateDisplay();
    }
    
    handleOperator(operator) {
        if (this.operation && !this.shouldResetDisplay) {
            this.calculate();
        }
        
        this.previousValue = this.currentValue;
        this.operation = operator;
        this.shouldResetDisplay = true;
        this.updateHistoryDisplay();
    }
    
    handleFunction(action) {
        switch (action) {
            case 'clear':
                this.clear();
                break;
            case 'delete':
                this.delete();
                break;
            case 'percent':
                this.handleOperator('%');
                break;
        }
    }
    
    handleScientific(func) {
        const value = parseFloat(this.currentValue);
        let result;
        
        switch (func) {
            case 'sin':
                result = Math.sin(value * Math.PI / 180);
                break;
            case 'cos':
                result = Math.cos(value * Math.PI / 180);
                break;
            case 'tan':
                result = Math.tan(value * Math.PI / 180);
                break;
            case 'log':
                result = Math.log10(value);
                break;
            case 'ln':
                result = Math.log(value);
                break;
            case 'sqrt':
                result = Math.sqrt(value);
                break;
            case 'pow2':
                result = value * value;
                break;
            case 'pow3':
                result = value * value * value;
                break;
            case 'pi':
                result = Math.PI;
                break;
        }
        
        if (result !== undefined && !isNaN(result)) {
            const expression = `${func}(${this.currentValue})`;
            this.addToHistory(expression, result);
            this.currentValue = result.toString();
            this.shouldResetDisplay = true;
            this.updateDisplay();
        }
    }
    
    calculate() {
        if (!this.operation || !this.previousValue) return;
        
        const prev = parseFloat(this.previousValue);
        const current = parseFloat(this.currentValue);
        let result;
        
        switch (this.operation) {
            case '+':
                result = prev + current;
                break;
            case '-':
                result = prev - current;
                break;
            case '*':
                result = prev * current;
                break;
            case '/':
                if (current === 0) {
                    this.showError('لا يمكن القسمة على صفر');
                    return;
                }
                result = prev / current;
                break;
            case '%':
                result = prev % current;
                break;
        }
        
        if (result !== undefined && !isNaN(result)) {
            const expression = `${this.previousValue} ${this.operation} ${this.currentValue}`;
            this.addToHistory(expression, result);
            this.currentValue = result.toString();
            this.operation = null;
            this.previousValue = '';
            this.shouldResetDisplay = true;
            this.updateDisplay();
            this.updateHistoryDisplay();
        }
    }
    
    clear() {
        this.currentValue = '0';
        this.previousValue = '';
        this.operation = null;
        this.shouldResetDisplay = false;
        this.updateDisplay();
        this.updateHistoryDisplay();
    }
    
    delete() {
        if (this.currentValue.length > 1) {
            this.currentValue = this.currentValue.slice(0, -1);
        } else {
            this.currentValue = '0';
        }
        this.updateDisplay();
    }
    
    updateDisplay() {
        // Format large numbers
        let displayValue = this.currentValue;
        if (displayValue.length > 12) {
            const num = parseFloat(displayValue);
            if (!isNaN(num)) {
                displayValue = num.toExponential(6);
            }
        }
        this.display.textContent = displayValue;
    }
    
    updateHistoryDisplay() {
        let historyText = '';
        if (this.previousValue && this.operation) {
            historyText = `${this.previousValue} ${this.operation}`;
        }
        this.historyDisplay.textContent = historyText;
    }
    
    addToHistory(expression, result) {
        const historyItem = {
            expression,
            result: result.toString(),
            timestamp: new Date().toISOString()
        };
        
        this.history.unshift(historyItem);
        if (this.history.length > 50) {
            this.history.pop();
        }
        
        this.saveHistory();
        this.renderHistory();
    }
    
    renderHistory() {
        if (!this.historyList) return;
        
        this.historyList.innerHTML = '';
        
        this.history.forEach(item => {
            const historyElement = document.createElement('div');
            historyElement.className = 'history-item';
            historyElement.innerHTML = `
                <div class="history-expression">${item.expression}</div>
                <div class="history-result">= ${item.result}</div>
            `;
            this.historyList.appendChild(historyElement);
        });
    }
    
    useHistoryItem(item) {
        const expression = item.querySelector('.history-expression').textContent;
        const result = item.querySelector('.history-result').textContent.replace('= ', '');
        
        this.currentValue = result;
        this.updateDisplay();
        this.clear();
    }
    
    clearHistory() {
        this.history = [];
        this.saveHistory();
        this.renderHistory();
    }
    
    saveHistory() {
        localStorage.setItem('cute-calculator-history', JSON.stringify(this.history));
    }
    
    loadHistory() {
        const saved = localStorage.getItem('cute-calculator-history');
        if (saved) {
            this.history = JSON.parse(saved);
            this.renderHistory();
        }
    }
    
    toggleHistory() {
        if (this.isHistoryOpen) {
            this.closeHistoryPanel();
        } else {
            this.openHistory();
        }
    }
    
    toggleScientific() {
        if (this.isScientificOpen) {
            this.closeScientificPanel();
        } else {
            this.openScientific();
        }
    }
    
    openHistory() {
        this.closeScientificPanel(); // Close other panel first
        this.isHistoryOpen = true;
        this.historyPanel.classList.add('open');
        this.overlay.classList.add('active');
        this.historyToggle.classList.add('active');
    }
    
    closeHistoryPanel() {
        this.isHistoryOpen = false;
        this.historyPanel.classList.remove('open');
        this.overlay.classList.remove('active');
        this.historyToggle.classList.remove('active');
    }
    
    openScientific() {
        this.closeHistoryPanel(); // Close other panel first
        this.isScientificOpen = true;
        this.scientificPanel.classList.add('open');
        this.overlay.classList.add('active');
        this.scientificToggle.classList.add('active');
    }
    
    closeScientificPanel() {
        this.isScientificOpen = false;
        this.scientificPanel.classList.remove('open');
        this.overlay.classList.remove('active');
        this.scientificToggle.classList.remove('active');
    }
    
    closeAllPanels() {
        this.closeHistoryPanel();
        this.closeScientificPanel();
    }
    
    handleKeyboard(e) {
        // Prevent default for calculator keys
        if (e.key.match(/[0-9+\-*/.=]|Enter|Backspace|Delete|Escape/)) {
            e.preventDefault();
        }
        
        switch (e.key) {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                this.appendNumber(e.key);
                break;
            case '.':
                this.appendNumber('.');
                break;
            case '+':
                this.handleOperator('+');
                break;
            case '-':
                this.handleOperator('-');
                break;
            case '*':
                this.handleOperator('*');
                break;
            case '/':
                this.handleOperator('/');
                break;
            case '%':
                this.handleOperator('%');
                break;
            case 'Enter':
            case '=':
                this.calculate();
                break;
            case 'Backspace':
                this.delete();
                break;
            case 'Escape':
            case 'c':
            case 'C':
                this.clear();
                break;
        }
    }
    
    showError(message) {
        this.display.textContent = message;
        this.display.classList.add('error');
        setTimeout(() => {
            this.display.classList.remove('error');
            this.clear();
        }, 2000);
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CuteCalculator();
});
