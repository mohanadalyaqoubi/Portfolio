// Royal Cafe Premium Menu JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize AOS
    AOS.init({
        duration: 1000,
        easing: 'ease-in-out',
        once: true,
        offset: 100
    });

    // Hide loading screen
    setTimeout(() => {
        const loadingScreen = document.querySelector('.loading-screen');
        loadingScreen.classList.add('hidden');
    }, 2000);

    // Category filtering functionality
    const categoryButtons = document.querySelectorAll('.cat-btn');
    const menuSections = document.querySelectorAll('.menu-section');
    const menuItems = document.querySelectorAll('.menu-item');
    
    // Add click event listeners to category buttons
    categoryButtons.forEach(button => {
        button.addEventListener('click', function() {
            const selectedCategory = this.getAttribute('data-category');
            
            // Update active button state
            categoryButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filter menu sections and items
            filterMenu(selectedCategory);
            
            // Add animation effect
            animateFiltering();
        });
    });
    
    // Filter menu based on category
    function filterMenu(category) {
        menuSections.forEach(section => {
            const sectionItems = section.querySelectorAll('.menu-item');
            
            if (category === 'all') {
                section.classList.remove('hidden');
                sectionItems.forEach(item => {
                    item.classList.remove('hidden');
                    animateItem(item);
                });
            } else {
                if (section.id === category) {
                    section.classList.remove('hidden');
                    sectionItems.forEach(item => {
                        item.classList.remove('hidden');
                        animateItem(item);
                    });
                } else {
                    section.classList.add('hidden');
                }
            }
        });
    }
    
    // Animate individual items
    function animateItem(item) {
        item.style.opacity = '0';
        item.style.transform = 'translateY(30px)';
        
        setTimeout(() => {
            item.style.transition = 'all 0.6s ease';
            item.style.opacity = '1';
            item.style.transform = 'translateY(0)';
        }, 100);
    }
    
    // Add filtering animation
    function animateFiltering() {
        const menuContent = document.querySelector('.menu-content');
        menuContent.style.opacity = '0.8';
        setTimeout(() => {
            menuContent.style.transition = 'opacity 0.3s ease';
            menuContent.style.opacity = '1';
        }, 100);
    }
    
    
    // Add hover effects to menu items
    menuItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px) scale(1.02)';
        });
        
        item.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0) scale(1)';
        });
        
        // Add click effect for better user feedback
        item.addEventListener('click', function() {
            this.style.transform = 'translateY(-5px) scale(0.98)';
            setTimeout(() => {
                this.style.transform = 'translateY(-10px) scale(1.02)';
            }, 150);
        });
    });
    
    // Smooth scroll for internal links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Add keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            // Search functionality removed
        }
        
        // Focus search on Ctrl+F or Cmd+F
        if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
            e.preventDefault();
            // Search functionality removed
        }
    });
    
    // Add scroll to top button
    const scrollToTopBtn = document.createElement('button');
    scrollToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    scrollToTopBtn.className = 'scroll-to-top';
    
    // Add scroll to top styles
    const scrollStyles = `
        .scroll-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 55px;
            height: 55px;
            background: linear-gradient(135deg, var(--primary-gold), var(--secondary-gold));
            color: white;
            border: none;
            border-radius: 50%;
            cursor: pointer;
            display: none;
            justify-content: center;
            align-items: center;
            font-size: 1.3rem;
            z-index: 999;
            transition: all 0.3s ease;
            box-shadow: 0 8px 25px rgba(212, 175, 55, 0.3);
        }
        
        .scroll-to-top:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 35px rgba(212, 175, 55, 0.4);
        }
        
        .scroll-to-top.show {
            display: flex;
            animation: fadeInUp 0.5s ease;
        }
        
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
    `;
    
    const scrollStyleSheet = document.createElement('style');
    scrollStyleSheet.textContent = scrollStyles;
    document.head.appendChild(scrollStyleSheet);
    
    document.body.appendChild(scrollToTopBtn);
    
    // Show/hide scroll to top button
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 500) {
            scrollToTopBtn.classList.add('show');
        } else {
            scrollToTopBtn.classList.remove('show');
        }
    });
    
    // Scroll to top functionality
    scrollToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    
    // Add parallax effect to background
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const bgParticles = document.querySelector('.bg-particles');
        const bgGradient = document.querySelector('.bg-gradient');
        
        if (bgParticles) {
            bgParticles.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
        
        if (bgGradient) {
            bgGradient.style.transform = `translateY(${scrolled * 0.3}px)`;
        }
    });
    
    // Add intersection observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);
    
    // Observe menu sections
    menuSections.forEach(section => {
        observer.observe(section);
    });
    
    // Add loading animation for images
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('load', function() {
            this.style.animation = 'fadeIn 0.5s ease';
        });
        
        img.addEventListener('error', function() {
            this.src = 'https://via.placeholder.com/400x300/8B4513/FFFFFF?text=Image+Not+Available';
        });
    });
    
    // Add image fade-in animation
    const imageStyles = `
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `;
    
    const imageStyleSheet = document.createElement('style');
    imageStyleSheet.textContent = imageStyles;
    document.head.appendChild(imageStyleSheet);
    
    // Add dynamic year to footer
    const yearSpan = document.querySelector('.copyright p');
    if (yearSpan && yearSpan.textContent.includes('2024')) {
        yearSpan.innerHTML = yearSpan.innerHTML.replace('2024', new Date().getFullYear());
    }
    
    // Add performance optimization
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(function() {
            // Re-initialize animations on resize
            AOS.refresh();
        }, 250);
    });
    
    // Console log for debugging
    console.log('Royal Cafe Premium Menu loaded successfully!');
    console.log('Categories: Hot Drinks, Cold Drinks, Desserts, Argileh');
    console.log('Features: Category filtering, animations, responsive design');
});
