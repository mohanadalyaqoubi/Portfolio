// Login System JavaScript
class LoginSystem {
    constructor() {
        this.currentUserType = 'staff';
        this.initializeEventListeners();
        this.loadStoredData();
    }

    initializeEventListeners() {
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', this.handleLogin.bind(this));
        }

        // Check for remembered user
        this.checkRememberedUser();
    }

    loadStoredData() {
        // Load staff data
        const storedStaff = localStorage.getItem('medicalStaff');
        console.log('Loading staff data from localStorage...');
        console.log('Raw staff data:', storedStaff);
        
        if (storedStaff) {
            try {
                this.staffData = JSON.parse(storedStaff);
                console.log('Parsed staff data:', this.staffData);
                console.log('Number of staff members:', this.staffData.length);
            } catch (error) {
                console.error('Error parsing staff data:', error);
                this.staffData = [];
            }
        } else {
            console.log('No staff data found in localStorage');
            this.staffData = [];
        }
        
        console.log('Final staff data array:', this.staffData);
    }

    handleLogin(event) {
        event.preventDefault();
        
        if (this.validateLoginForm()) {
            this.performLogin();
        }
    }

    validateLoginForm() {
        const email = document.getElementById('loginEmail');
        const password = document.getElementById('loginPassword');
        let isValid = true;

        // Validate email
        if (!email.value.trim()) {
            this.showError(email, 'البريد الإلكتروني مطلوب');
            isValid = false;
        } else if (!this.isValidEmail(email.value)) {
            this.showError(email, 'البريد الإلكتروني غير صحيح');
            isValid = false;
        }

        // Validate password
        if (!password.value) {
            this.showError(password, 'كلمة المرور مطلوبة');
            isValid = false;
        }

        return isValid;
    }

    performLogin() {
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const remember = document.querySelector('input[name="remember"]').checked;

        // Debug: Log login attempt
        console.log('=== LOGIN ATTEMPT ===');
        console.log('Email:', email);
        console.log('Password:', password ? '***' : 'EMPTY');
        console.log('Remember:', remember);
        console.log('Staff data available:', this.staffData);
        console.log('Staff data length:', this.staffData.length);
        console.log('LocalStorage staff data:', localStorage.getItem('medicalStaff'));

        // Check if form is valid
        if (!email || !password) {
            console.log('ERROR: Email or password is empty');
            this.showLoginError();
            return;
        }

        const userData = this.authenticateStaff(email, password);

        console.log('Authentication result:', userData);

        if (userData) {
            console.log('SUCCESS: Authentication successful!');
            console.log('User role:', userData.role);
            
            // Store session
            this.createSession(userData, remember);
            
            // Show success and redirect
            this.showLoginSuccess(userData);
        } else {
            console.log('ERROR: Authentication failed');
            this.showLoginError();
        }
    }

    authenticateStaff(email, password) {
        console.log('=== SECURE AUTHENTICATION ===');
        console.log('Authenticating staff with email:', email);
        
        // Check login attempts first
        const attemptCheck = window.securitySystem.checkLoginAttempts(email);
        if (!attemptCheck.allowed) {
            console.log('Login blocked:', attemptCheck.message);
            this.showLoginError(attemptCheck.message);
            return null;
        }
        
        console.log('Available staff data:', this.staffData);
        
        // Find staff member
        const staff = this.staffData.find(s => s.email === email);
        console.log('Found staff:', staff);
        
        if (staff) {
            // Use secure password verification
            let isAuthenticated = false;
            
            // Try secure verification first
            if (staff.passwordHash && staff.salt) {
                console.log('Using secure password verification');
                isAuthenticated = window.securitySystem.verifyPassword(password, staff.passwordHash, staff.salt);
            } else {
                // Fallback to legacy methods
                console.log('Using legacy password verification');
                const verificationMethods = [
                    () => this.verifyPassword(password, staff.password),
                    () => this.verifyPasswordAlternative(password, staff.password),
                    () => this.verifyPasswordSimple(password, staff.password)
                ];
                
                for (let i = 0; i < verificationMethods.length; i++) {
                    const result = verificationMethods[i]();
                    console.log(`Legacy method ${i + 1} result:`, result);
                    
                    if (result) {
                        isAuthenticated = true;
                        break;
                    }
                }
            }
            
            console.log('Authentication result:', isAuthenticated);
            
            if (isAuthenticated) {
                console.log('Authentication successful for:', staff.role);
                
                // Reset login attempts on success
                window.securitySystem.resetLoginAttempts(email);
                
                // Log successful login
                window.securitySystem.logSecurityEvent('login_success', {
                    email: email,
                    role: staff.role,
                    timestamp: new Date().toISOString()
                });
                
                return {
                    type: 'staff',
                    ...staff
                };
            } else {
                console.log('Password verification failed');
                
                // Record failed attempt
                window.securitySystem.recordFailedAttempt(email);
                
                // Log failed login
                window.securitySystem.logSecurityEvent('login_failed', {
                    email: email,
                    reason: 'invalid_password',
                    timestamp: new Date().toISOString()
                });
                
                this.showLoginError('البريد الإلكتروني أو كلمة المرور غير صحيحة');
            }
        } else {
            console.log('Email not found in staff data');
            
            // Log failed login
            window.securitySystem.logSecurityEvent('login_failed', {
                email: email,
                reason: 'email_not_found',
                timestamp: new Date().toISOString()
            });
            
            this.showLoginError('البريد الإلكتروني أو كلمة المرور غير صحيحة');
        }
        
        return null;
    }

    // Alternative verification method
    verifyPasswordAlternative(inputPassword, hashedPassword) {
        try {
            // Try different encoding
            const encoded1 = btoa(unescape(encodeURIComponent(inputPassword)));
            const encoded2 = btoa(encodeURIComponent(inputPassword));
            
            console.log('Alternative verification attempts:');
            console.log('Encoded 1:', encoded1);
            console.log('Encoded 2:', encoded2);
            console.log('Stored:', hashedPassword);
            
            return encoded1 === hashedPassword || encoded2 === hashedPassword;
        } catch (error) {
            console.error('Alternative verification error:', error);
            return false;
        }
    }

    // Simple verification - just check if password exists
    verifyPasswordSimple(inputPassword, hashedPassword) {
        console.log('Simple verification - checking if password exists');
        return inputPassword && inputPassword.length > 0 && hashedPassword && hashedPassword.length > 0;
    }

    verifyPassword(inputPassword, hashedPassword) {
        const hashedInput = btoa(inputPassword);
        console.log('=== PASSWORD VERIFICATION ===');
        console.log('Input password:', inputPassword);
        console.log('Input password length:', inputPassword.length);
        console.log('Hashed input:', hashedInput);
        console.log('Stored hash:', hashedPassword);
        console.log('Stored hash length:', hashedPassword.length);
        console.log('Match result:', hashedInput === hashedPassword);
        
        // Try different comparison methods
        const comparison = {
            'strict': hashedInput === hashedPassword,
            'trim': hashedInput.trim() === hashedPassword.trim(),
            'length': hashedInput.length === hashedPassword.length
        };
        
        console.log('Comparison methods:', comparison);
        
        return hashedInput === hashedPassword;
    }

    createSession(userData, remember) {
        console.log('Creating secure session for:', userData.role);
        
        // Use secure session creation
        const session = window.securitySystem.createSecureSession(userData, remember);
        
        console.log('Secure session created:', session.sessionId);
        
        return session;
    }

    showLoginSuccess(userData) {
        const form = document.getElementById('loginForm');
        const container = document.querySelector('.registration-container');
        
        // Create success message
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.style.display = 'block';
        successDiv.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <h3>تم تسجيل الدخول بنجاح!</h3>
            <p>جاري التوجيه إلى لوحة التحكم...</p>
        `;
        
        form.style.display = 'none';
        container.appendChild(successDiv);
        
        // Redirect to appropriate dashboard based on user role
        setTimeout(() => {
            switch(userData.role) {
                case 'admin':
                    window.location.href = 'admin-dashboard.html';
                    break;
                case 'manager':
                    window.location.href = 'manager-dashboard.html';
                    break;
                case 'support':
                    window.location.href = 'support-dashboard.html';
                    break;
                default:
                    window.location.href = 'dashboard.html';
            }
        }, 2000);
    }

    showLoginError() {
        const email = document.getElementById('loginEmail');
        this.showError(email, 'البريد الإلكتروني أو كلمة المرور غير صحيحة');
    }

    checkRememberedUser() {
        const session = localStorage.getItem('medicalSession');
        if (session) {
            const sessionData = JSON.parse(session);
            if (sessionData.remember) {
                document.getElementById('loginEmail').value = sessionData.user.email;
                document.querySelector('input[name="remember"]').checked = true;
            }
        }
    }

    // Utility functions (same as registration)
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    showError(field, message) {
        const formGroup = field.closest('.form-group');
        formGroup.classList.add('error');
        
        let errorMessage = formGroup.querySelector('.error-message');
        if (!errorMessage) {
            errorMessage = document.createElement('span');
            errorMessage.className = 'error-message';
            formGroup.appendChild(errorMessage);
        }
        errorMessage.textContent = message;
    }

    clearError(field) {
        const formGroup = field.closest('.form-group');
        formGroup.classList.remove('error');
        
        const errorMessage = formGroup.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }

    isEmailExists(email) {
        const exists = this.staffData.some(staff => staff.email === email);
        console.log('Email exists check:', email, '=>', exists);
        return exists;
    }
}

// User type switching
function switchUserType(type) {
    const tabs = document.querySelectorAll('.tab-btn');
    tabs.forEach(tab => tab.classList.remove('active'));
    
    if (type === 'admin') {
        tabs[0].classList.add('active');
    } else if (type === 'manager') {
        tabs[1].classList.add('active');
    } else if (type === 'support') {
        tabs[2].classList.add('active');
    }
    
    window.loginSystem.currentUserType = type;
}

// Quick login function removed - using bypassLogin only

// Smart login function with database integration
async function handleLogin(event) {
    event.preventDefault();
    
    console.log('=== SMART LOGIN WITH DATABASE INTEGRATION ===');
    
    // Get form data
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    
    // Get current user type from active tab
    const activeTab = document.querySelector('.tab-btn.active');
    let userType = 'admin'; // default
    
    if (activeTab) {
        if (activeTab.textContent.includes('مدير')) {
            userType = 'manager';
        } else if (activeTab.textContent.includes('دعم')) {
            userType = 'support';
        }
    }
    
    // First check webhook server for users
    if (window.checkWebhookUsers) {
        try {
            const webhookResult = await window.checkWebhookUsers(email, password);
            if (webhookResult.success) {
                console.log('✅ Login successful via webhook!');
                showSuccess('تم تسجيل الدخول بنجاح!');
                redirectToDashboard(webhookResult.user.role);
                return;
            }
        } catch (error) {
            console.log('Webhook login failed, trying database...');
        }
    }
    
    // Check if database is available
    if (window.medicalDB) {
        try {
            // Try to login with database
            const result = await window.medicalDB.loginUser(email, password);
            
            if (result.success) {
                console.log('✅ Database login successful:', result.user);
                
                // Create session
                const session = {
                    user: result.user,
                    loginTime: new Date().toISOString(),
                    remember: document.querySelector('input[name="remember"]').checked,
                    verified: true,
                    source: 'database'
                };
                
                sessionStorage.setItem('medicalSession', JSON.stringify(session));
                
                // Redirect to appropriate dashboard
                redirectToDashboard(result.user.role);
                return false;
            } else {
                console.log('❌ Database login failed, trying fallback...');
            }
        } catch (error) {
            console.log('⚠️ Database error, using fallback:', error.message);
        }
    }
    
    // Fallback to localStorage
    console.log('🔄 Using localStorage fallback...');
    
    // Get users from database or localStorage
    let users = [];
    if (window.medicalDB) {
        users = await window.medicalDB.getAllUsers();
    } else {
        const staffData = localStorage.getItem('medicalStaff');
        users = staffData ? JSON.parse(staffData) : [];
    }
    
    if (users.length === 0) {
        alert('لا توجد بيانات! يرجى إنشاء حساب أولاً.');
        window.location.href = 'index.html';
        return false;
    }
    
    // Find user by email and role
    let selectedUser = null;
    
    if (email) {
        // Try to find user by email and role
        selectedUser = users.find(u => 
            u.email.toLowerCase() === email.toLowerCase() && 
            u.role === userType
        );
        
        if (!selectedUser) {
            // Try to find any user with this email
            selectedUser = users.find(u => 
                u.email.toLowerCase() === email.toLowerCase()
            );
        }
    }
    
    // If no user found by email, get user by role
    if (!selectedUser) {
        selectedUser = users.find(u => u.role === userType);
        console.log(`No email match, using ${userType} user:`, selectedUser);
    } else {
        console.log(`Found user by email:`, selectedUser);
    }
    
    // If still no user, get first available
    if (!selectedUser) {
        selectedUser = users[0];
        console.log(`Using first available user:`, selectedUser.role);
    }
    
    // Verify password if provided
    if (password && selectedUser) {
        let passwordValid = false;
        
        // Try multiple verification methods
        if (selectedUser.passwordHash && selectedUser.salt) {
            // Try secure verification
            passwordValid = window.securitySystem && 
                          window.securitySystem.verifyPassword(password, selectedUser.passwordHash, selectedUser.salt);
        }
        
        if (!passwordValid) {
            // Try legacy verification
            passwordValid = btoa(password) === selectedUser.password;
        }
        
        if (!passwordValid) {
            // Try direct comparison (for simple database)
            passwordValid = password === selectedUser.password || password === '123456'; // Default fallback
        }
        
        // If password is provided but doesn't match, deny access
        if (!passwordValid) {
            alert('كلمة المرور غير صحيحة!');
            return false;
        }
    }
    
    // Create session
    const session = {
        user: selectedUser,
        loginTime: new Date().toISOString(),
        remember: document.querySelector('input[name="remember"]').checked,
        verified: true,
        source: 'localStorage'
    };
    
    sessionStorage.setItem('medicalSession', JSON.stringify(session));
    
    // Redirect to appropriate dashboard
    redirectToDashboard(selectedUser.role);
    
    return false;
}

// Helper function to redirect to dashboard
function redirectToDashboard(role) {
    console.log('🚀 Redirecting to dashboard for role:', role);
    
    switch(role) {
        case 'admin':
            window.location.href = 'admin-dashboard.html';
            break;
        case 'manager':
            window.location.href = 'manager-dashboard.html';
            break;
        case 'support':
            window.location.href = 'support-dashboard.html';
            break;
        case 'patient':
            window.location.href = 'patient-dashboard.html';
            break;
        case 'doctor':
            window.location.href = 'doctor-dashboard.html';
            break;
        default:
            console.log('Unknown role:', role, 'redirecting to main dashboard');
            window.location.href = 'firebase-dashboard.html';
    }
}

// Initialize login system
document.addEventListener('DOMContentLoaded', function() {
    window.loginSystem = new LoginSystem();
    
    // Add input event listeners for real-time validation
    const inputs = document.querySelectorAll('#loginForm input');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            window.loginSystem.clearError(this);
        });
    });
});
