// Firebase Configuration - Replace with your actual Firebase project config
const firebaseConfig = {
    // TODO: Replace these values with your actual Firebase project configuration
    apiKey: "YOUR_API_KEY_HERE",
    authDomain: "YOUR_PROJECT.firebaseapp.com",
    databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
    projectId: "YOUR_PROJECT_ID",
    storageBucket: "YOUR_PROJECT.appspot.com",
    messagingSenderId: "YOUR_SENDER_ID",
    appId: "YOUR_APP_ID"
};

// Alternative: Use environment variables or config file
// const firebaseConfig = {
//     apiKey: process.env.FIREBASE_API_KEY,
//     authDomain: process.env.FIREBASE_AUTH_DOMAIN,
//     databaseURL: process.env.FIREBASE_DATABASE_URL,
//     projectId: process.env.FIREBASE_PROJECT_ID,
//     storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
//     messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID,
//     appId: process.env.FIREBASE_APP_ID
// };

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

// Initialize Firebase services
const auth = firebase.auth();
const database = firebase.database();
const storage = firebase.storage();

// Medical Booking System Database Class
class MedicalDatabase {
    constructor() {
        this.db = database;
        this.auth = auth;
        this.storage = storage;
    }

    // Authentication Methods
    async registerUser(userData) {
        try {
            // Create auth user
            const userCredential = await this.auth.createUserWithEmailAndPassword(
                userData.email, 
                userData.password
            );
            
            // Add user data to database
            await this.db.ref(`users/${userCredential.user.uid}`).set({
                uid: userCredential.user.uid,
                fullName: userData.fullName,
                email: userData.email,
                phone: userData.phone,
                role: userData.role,
                department: userData.department || null,
                level: userData.level || null,
                shift: userData.shift || null,
                createdAt: firebase.database.ServerValue.TIMESTAMP,
                status: 'active',
                lastLogin: null
            });

            return { success: true, user: userCredential.user };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async loginUser(email, password) {
        try {
            const userCredential = await this.auth.signInWithEmailAndPassword(email, password);
            
            // Update last login
            await this.db.ref(`users/${userCredential.user.uid}`).update({
                lastLogin: firebase.database.ServerValue.TIMESTAMP
            });

            // Get user data
            const userData = await this.getUserData(userCredential.user.uid);
            
            return { success: true, user: userData };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async logout() {
        try {
            await this.auth.signOut();
            return { success: true };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // User Data Methods
    async getUserData(uid) {
        try {
            const snapshot = await this.db.ref(`users/${uid}`).once('value');
            return snapshot.val();
        } catch (error) {
            return null;
        }
    }

    async getAllUsers() {
        try {
            const snapshot = await this.db.ref('users').once('value');
            const users = snapshot.val();
            return users ? Object.values(users) : [];
        } catch (error) {
            return [];
        }
    }

    async getUsersByRole(role) {
        try {
            const snapshot = await this.db.ref('users').orderByChild('role').equalTo(role).once('value');
            const users = snapshot.val();
            return users ? Object.values(users) : [];
        } catch (error) {
            return [];
        }
    }

    // Patient Management
    async addPatient(patientData) {
        try {
            const newPatientRef = this.db.ref('patients').push();
            await newPatientRef.set({
                id: newPatientRef.key,
                ...patientData,
                createdAt: firebase.database.ServerValue.TIMESTAMP,
                status: 'active'
            });
            return { success: true, id: newPatientRef.key };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async getAllPatients() {
        try {
            const snapshot = await this.db.ref('patients').once('value');
            const patients = snapshot.val();
            return patients ? Object.values(patients) : [];
        } catch (error) {
            return [];
        }
    }

    // Appointment Management
    async addAppointment(appointmentData) {
        try {
            const newAppointmentRef = this.db.ref('appointments').push();
            await newAppointmentRef.set({
                id: newAppointmentRef.key,
                ...appointmentData,
                createdAt: firebase.database.ServerValue.TIMESTAMP,
                status: 'pending'
            });
            return { success: true, id: newAppointmentRef.key };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    async getAllAppointments() {
        try {
            const snapshot = await this.db.ref('appointments').once('value');
            const appointments = snapshot.val();
            return appointments ? Object.values(appointments) : [];
        } catch (error) {
            return [];
        }
    }

    // Real-time listeners
    onUsersChanged(callback) {
        return this.db.ref('users').on('value', (snapshot) => {
            const users = snapshot.val();
            callback(users ? Object.values(users) : []);
        });
    }

    onPatientsChanged(callback) {
        return this.db.ref('patients').on('value', (snapshot) => {
            const patients = snapshot.val();
            callback(patients ? Object.values(patients) : []);
        });
    }

    onAppointmentsChanged(callback) {
        return this.db.ref('appointments').on('value', (snapshot) => {
            const appointments = snapshot.val();
            callback(appointments ? Object.values(appointments) : []);
        });
    }

    // Data Sync Methods
    async syncData() {
        try {
            const [users, patients, appointments] = await Promise.all([
                this.getAllUsers(),
                this.getAllPatients(),
                this.getAllAppointments()
            ]);

            return {
                success: true,
                data: { users, patients, appointments }
            };
        } catch (error) {
            return { success: false, error: error.message };
        }
    }

    // Backup Methods
    async createBackup() {
        try {
            const data = await this.syncData();
            if (data.success) {
                const backupData = {
                    timestamp: firebase.database.ServerValue.TIMESTAMP,
                    ...data.data
                };
                
                const backupRef = this.db.ref('backups').push();
                await backupRef.set(backupData);
                
                return { success: true, backupId: backupRef.key };
            }
            return data;
        } catch (error) {
            return { success: false, error: error.message };
        }
    }
}

// Initialize database instance
window.medicalDB = new MedicalDatabase();

// Auth state observer
firebase.auth().onAuthStateChanged((user) => {
    if (user) {
        console.log('User is signed in:', user.uid);
        // Load user data
        window.medicalDB.getUserData(user.uid).then(userData => {
            window.currentUser = userData;
        });
    } else {
        console.log('User is signed out');
        window.currentUser = null;
    }
});
