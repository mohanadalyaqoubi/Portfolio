// Medical Booking System JavaScript
class MedicalBookingSystem {
    constructor() {
        this.staff = [];
        this.initializeEventListeners();
        this.loadStoredData();
    }

    initializeEventListeners() {
        // Admin registration form
        const adminForm = document.getElementById('adminRegistrationForm');
        if (adminForm) {
            adminForm.addEventListener('submit', this.handleAdminRegistration.bind(this));
        }

        // Manager registration form
        const managerForm = document.getElementById('managerRegistrationForm');
        if (managerForm) {
            managerForm.addEventListener('submit', this.handleManagerRegistration.bind(this));
        }

        // Support registration form
        const supportForm = document.getElementById('supportRegistrationForm');
        if (supportForm) {
            supportForm.addEventListener('submit', this.handleSupportRegistration.bind(this));
        }

        // Real-time validation for all forms
        const inputs = document.querySelectorAll('input, select');
        inputs.forEach(input => {
            input.addEventListener('blur', this.validateField.bind(this));
            input.addEventListener('input', this.clearError.bind(this));
        });

        // Password confirmation validation
        this.setupPasswordValidation();
    }

    setupPasswordValidation() {
        // Admin form password validation
        const adminPassword = document.getElementById('adminPassword');
        const adminConfirmPassword = document.getElementById('adminConfirmPassword');
        if (adminPassword && adminConfirmPassword) {
            adminConfirmPassword.addEventListener('input', () => {
                this.validatePasswordMatch(adminPassword, adminConfirmPassword);
            });
        }

        // Manager form password validation
        const managerPassword = document.getElementById('managerPassword');
        const managerConfirmPassword = document.getElementById('managerConfirmPassword');
        if (managerPassword && managerConfirmPassword) {
            managerConfirmPassword.addEventListener('input', () => {
                this.validatePasswordMatch(managerPassword, managerConfirmPassword);
            });
        }

        // Support form password validation
        const supportPassword = document.getElementById('supportPassword');
        const supportConfirmPassword = document.getElementById('supportConfirmPassword');
        if (supportPassword && supportConfirmPassword) {
            supportConfirmPassword.addEventListener('input', () => {
                this.validatePasswordMatch(supportPassword, supportConfirmPassword);
            });
        }
    }

    loadStoredData() {
        // Load staff data
        const storedStaff = localStorage.getItem('medicalStaff');
        if (storedStaff) {
            this.staff = JSON.parse(storedStaff);
        } else {
            this.staff = [];
        }
    }

    handleAdminRegistration(event) {
        event.preventDefault();
        
        if (this.validateAdminForm()) {
            this.createAdminAccount();
        }
    }

    handleManagerRegistration(event) {
        event.preventDefault();
        
        if (this.validateManagerForm()) {
            this.createManagerAccount();
        }
    }

    handleSupportRegistration(event) {
        event.preventDefault();
        
        if (this.validateSupportForm()) {
            this.createSupportAccount();
        }
    }

    validateAdminForm() {
        const form = document.getElementById('adminRegistrationForm');
        const formData = new FormData(form);
        let isValid = true;

        // Validate required fields
        const requiredFields = ['adminName', 'adminEmail', 'adminPhone', 'adminPassword'];
        requiredFields.forEach(fieldId => {
            const input = document.getElementById(fieldId);
            if (!input.value.trim()) {
                this.showError(input, 'هذا الحقل مطلوب');
                isValid = false;
            }
        });

        // Validate email format
        const email = document.getElementById('adminEmail');
        if (email.value && !this.isValidEmail(email.value)) {
            this.showError(email, 'البريد الإلكتروني غير صحيح');
            isValid = false;
        }

        // Validate phone format
        const phone = document.getElementById('adminPhone');
        if (phone.value && !this.isValidPhone(phone.value)) {
            this.showError(phone, 'رقم الهاتف غير صحيح');
            isValid = false;
        }

        // Validate password strength
        const password = document.getElementById('adminPassword');
        if (password.value && !this.isValidPassword(password.value)) {
            this.showError(password, 'كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام');
            isValid = false;
        }

        // Validate password match
        const confirmPassword = document.getElementById('adminConfirmPassword');
        if (password.value !== confirmPassword.value) {
            this.showError(confirmPassword, 'كلمات المرور غير متطابقة');
            isValid = false;
        }

        return isValid;
    }

    validateManagerForm() {
        const form = document.getElementById('managerRegistrationForm');
        let isValid = true;

        // Validate required fields
        const requiredFields = ['managerName', 'managerEmail', 'managerPhone', 'managerDepartment', 'managerLevel', 'managerPassword'];
        requiredFields.forEach(fieldId => {
            const input = document.getElementById(fieldId);
            if (!input.value.trim()) {
                this.showError(input, 'هذا الحقل مطلوب');
                isValid = false;
            }
        });

        // Validate email format
        const email = document.getElementById('managerEmail');
        if (email.value && !this.isValidEmail(email.value)) {
            this.showError(email, 'البريد الإلكتروني غير صحيح');
            isValid = false;
        }

        // Validate phone format
        const phone = document.getElementById('managerPhone');
        if (phone.value && !this.isValidPhone(phone.value)) {
            this.showError(phone, 'رقم الهاتف غير صحيح');
            isValid = false;
        }

        // Validate password strength
        const password = document.getElementById('managerPassword');
        if (password.value && !this.isValidPassword(password.value)) {
            this.showError(password, 'كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام');
            isValid = false;
        }

        // Validate password match
        const confirmPassword = document.getElementById('managerConfirmPassword');
        if (password.value !== confirmPassword.value) {
            this.showError(confirmPassword, 'كلمات المرور غير متطابقة');
            isValid = false;
        }

        return isValid;
    }

    validateSupportForm() {
        const form = document.getElementById('supportRegistrationForm');
        let isValid = true;

        // Validate required fields
        const requiredFields = ['supportName', 'supportEmail', 'supportPhone', 'supportDepartment', 'supportShift', 'supportPassword'];
        requiredFields.forEach(fieldId => {
            const input = document.getElementById(fieldId);
            if (!input.value.trim()) {
                this.showError(input, 'هذا الحقل مطلوب');
                isValid = false;
            }
        });

        // Validate email format
        const email = document.getElementById('supportEmail');
        if (email.value && !this.isValidEmail(email.value)) {
            this.showError(email, 'البريد الإلكتروني غير صحيح');
            isValid = false;
        }

        // Validate phone format
        const phone = document.getElementById('supportPhone');
        if (phone.value && !this.isValidPhone(phone.value)) {
            this.showError(phone, 'رقم الهاتف غير صحيح');
            isValid = false;
        }

        // Validate password strength
        const password = document.getElementById('supportPassword');
        if (password.value && !this.isValidPassword(password.value)) {
            this.showError(password, 'كلمة المرور يجب أن تكون 8 أحرف على الأقل وتحتوي على حروف وأرقام');
            isValid = false;
        }

        // Validate password match
        const confirmPassword = document.getElementById('supportConfirmPassword');
        if (password.value !== confirmPassword.value) {
            this.showError(confirmPassword, 'كلمات المرور غير متطابقة');
            isValid = false;
        }

        return isValid;
    }

    validatePasswordMatch(passwordField, confirmPasswordField) {
        if (passwordField.value !== confirmPasswordField.value) {
            this.showError(confirmPasswordField, 'كلمات المرور غير متطابقة');
        } else {
            this.clearError(confirmPasswordField);
        }
    }

    async createAdminAccount() {
        const form = document.getElementById('adminRegistrationForm');
        const formData = new FormData(form);
        
        // Check if database is available
        if (window.medicalDB) {
            try {
                // Create admin account in database
                const result = await window.medicalDB.registerUser({
                    fullName: formData.get('fullName'),
                    email: formData.get('email'),
                    phone: formData.get('phone'),
                    password: formData.get('password'),
                    role: 'admin',
                    department: 'system',
                    level: 'executive'
                });
                
                if (result.success) {
                    console.log('✅ Admin account created successfully in database!');
                    this.showSuccessMessage('تم إنشاء حساب الأدمن بنجاح!');
                    return;
                } else {
                    console.log('❌ Database registration failed, using fallback...');
                }
            } catch (error) {
                console.error('⚠️ Database error, falling back to localStorage:', error);
            }
        }
        
        // Fallback to localStorage if Firebase not available
        // Hash password securely
        let passwordHash, salt;
        if (window.securitySystem) {
            const result = window.securitySystem.hashPassword(formData.get('password'));
            passwordHash = result.hash;
            salt = result.salt;
        } else {
            // Fallback to simple hashing if security system not loaded
            passwordHash = this.hashPassword(formData.get('password'));
            salt = null;
            console.log('Security system not loaded, using fallback hashing');
        }
        
        const staffData = {
            id: this.generateId(),
            fullName: formData.get('fullName'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            role: 'admin',
            department: 'system',
            level: 'executive',
            password: this.hashPassword(formData.get('password')), // Legacy for compatibility
            passwordHash: passwordHash, // New secure hash
            salt: salt, // Salt for verification
            accountType: 'staff',
            createdAt: new Date().toISOString(),
            status: 'active'
        };

        // Check if email already exists
        if (this.isEmailExists(staffData.email)) {
            this.showError(document.getElementById('adminEmail'), 'البريد الإلكتروني مسجل بالفعل');
            return;
        }

        // Save to localStorage
        this.staff.push(staffData);
        
        // Debug: Log to console before saving
        console.log('=== CREATING ADMIN ACCOUNT ===');
        console.log('Staff data before save:', this.staff);
        console.log('New admin account data:', staffData);
        console.log('Original password:', formData.get('password'));
        console.log('Hashed password:', staffData.password);
        
        localStorage.setItem('medicalStaff', JSON.stringify(this.staff));
        
        // Debug: Log to console after saving
        console.log('Data saved to localStorage');
        console.log('LocalStorage content:', localStorage.getItem('medicalStaff'));
        console.log('Staff array after save:', this.staff);
        console.log('Total staff count:', this.staff.length);

        // Show success message and redirect
        this.showSuccessMessage('تم إنشاء حساب الأدمن بنجاح!');
    }

    createManagerAccount() {
        const form = document.getElementById('managerRegistrationForm');
        const formData = new FormData(form);
        
        // Hash password securely
        let passwordHash, salt;
        if (window.securitySystem) {
            const result = window.securitySystem.hashPassword(formData.get('password'));
            passwordHash = result.hash;
            salt = result.salt;
        } else {
            // Fallback to simple hashing if security system not loaded
            passwordHash = this.hashPassword(formData.get('password'));
            salt = null;
            console.log('Security system not loaded, using fallback hashing');
        }
        
        const staffData = {
            id: this.generateId(),
            fullName: formData.get('fullName'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            role: 'manager',
            department: formData.get('department'),
            level: formData.get('level'),
            password: this.hashPassword(formData.get('password')), // Legacy for compatibility
            passwordHash: passwordHash, // New secure hash
            salt: salt, // Salt for verification
            accountType: 'staff',
            createdAt: new Date().toISOString(),
            status: 'active'
        };

        // Check if email already exists
        if (this.isEmailExists(staffData.email)) {
            this.showError(document.getElementById('managerEmail'), 'البريد الإلكتروني مسجل بالفعل');
            return;
        }

        // Save to localStorage
        this.staff.push(staffData);
        
        // Debug: Log to console before saving
        console.log('=== CREATING MANAGER ACCOUNT ===');
        console.log('Staff data before save:', this.staff);
        console.log('New manager account data:', staffData);
        
        localStorage.setItem('medicalStaff', JSON.stringify(this.staff));
        
        // Debug: Log to console after saving
        console.log('Data saved to localStorage');
        console.log('LocalStorage content:', localStorage.getItem('medicalStaff'));
        console.log('Staff array after save:', this.staff);
        console.log('Total staff count:', this.staff.length);

        // Show success message and redirect
        this.showSuccessMessage('تم إنشاء حساب المدير بنجاح!');
    }

    createSupportAccount() {
        const form = document.getElementById('supportRegistrationForm');
        const formData = new FormData(form);
        
        // Hash password securely
        let passwordHash, salt;
        if (window.securitySystem) {
            const result = window.securitySystem.hashPassword(formData.get('password'));
            passwordHash = result.hash;
            salt = result.salt;
        } else {
            // Fallback to simple hashing if security system not loaded
            passwordHash = this.hashPassword(formData.get('password'));
            salt = null;
            console.log('Security system not loaded, using fallback hashing');
        }
        
        const staffData = {
            id: this.generateId(),
            fullName: formData.get('fullName'),
            email: formData.get('email'),
            phone: formData.get('phone'),
            role: 'support',
            department: formData.get('department'),
            shift: formData.get('shift'),
            password: this.hashPassword(formData.get('password')), // Legacy for compatibility
            passwordHash: passwordHash, // New secure hash
            salt: salt, // Salt for verification
            accountType: 'staff',
            createdAt: new Date().toISOString(),
            status: 'active'
        };

        // Check if email already exists
        if (this.isEmailExists(staffData.email)) {
            this.showError(document.getElementById('supportEmail'), 'البريد الإلكتروني مسجل بالفعل');
            return;
        }

        // Save to localStorage
        this.staff.push(staffData);
        
        // Debug: Log to console before saving
        console.log('=== CREATING SUPPORT ACCOUNT ===');
        console.log('Staff data before save:', this.staff);
        console.log('New support account data:', staffData);
        
        localStorage.setItem('medicalStaff', JSON.stringify(this.staff));
        
        // Debug: Log to console after saving
        console.log('Data saved to localStorage');
        console.log('LocalStorage content:', localStorage.getItem('medicalStaff'));
        console.log('Staff array after save:', this.staff);
        console.log('Total staff count:', this.staff.length);

        // Show success message and redirect
        this.showSuccessMessage('تم إنشاء حساب موظف الدعم بنجاح!');
    }

    isEmailExists(email) {
        return this.staff.some(staff => staff.email === email);
    }

    // Utility functions
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    isValidPhone(phone) {
        const phoneRegex = /^[\d\s\-\+\(\)]+$/;
        return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 10;
    }

    isValidPassword(password) {
        return password.length >= 8 && /[a-zA-Z]/.test(password) && /\d/.test(password);
    }

    showError(field, message) {
        const formGroup = field.closest('.form-group');
        formGroup.classList.add('error');
        
        let errorMessage = formGroup.querySelector('.error-message');
        if (!errorMessage) {
            errorMessage = document.createElement('span');
            errorMessage.className = 'error-message';
            formGroup.appendChild(errorMessage);
        }
        errorMessage.textContent = message;
    }

    clearError(event) {
        const field = event.target || event;
        const formGroup = field.closest('.form-group');
        formGroup.classList.remove('error');
        
        const errorMessage = formGroup.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }

    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    hashPassword(password) {
        // Use secure hashing system if available
        if (window.securitySystem) {
            const { hash, salt } = window.securitySystem.hashPassword(password);
            console.log('Secure hashing password:', password, '->', hash);
            console.log('Salt:', salt);
            return hash;
        } else {
            // Fallback to simple hashing
            const hashed = btoa(password);
            console.log('Fallback hashing password:', password, '->', hashed);
            return hashed;
        }
    }

    showSuccessMessage(message = 'تم إنشاء الحساب بنجاح!') {
        // Debug: Log success message
        console.log('=== SHOWING SUCCESS MESSAGE ===');
        console.log('Message:', message);
        
        // Hide all modals first
        const modals = document.querySelectorAll('.registration-modal');
        console.log('Found modals:', modals.length);
        modals.forEach(modal => {
            modal.style.display = 'none';
            console.log('Hidden modal:', modal.id);
        });
        
        // Create success message
        const successDiv = document.createElement('div');
        successDiv.className = 'success-message';
        successDiv.style.display = 'block';
        successDiv.style.position = 'fixed';
        successDiv.style.top = '50%';
        successDiv.style.left = '50%';
        successDiv.style.transform = 'translate(-50%, -50%)';
        successDiv.style.zIndex = '9999';
        successDiv.style.background = 'white';
        successDiv.style.padding = '40px';
        successDiv.style.borderRadius = '15px';
        successDiv.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.2)';
        successDiv.style.textAlign = 'center';
        successDiv.innerHTML = `
            <i class="fas fa-check-circle" style="color: #10B981; font-size: 48px; margin-bottom: 20px;"></i>
            <h3 style="color: #1F2937; margin-bottom: 10px;">تم إنشاء الحساب بنجاح!</h3>
            <p style="color: #6B7280; margin-bottom: 10px;">${message}</p>
            <p style="color: #4F46E5; font-size: 0.9rem;">سيتم توجيهك إلى صفحة تسجيل الدخول...</p>
        `;
        
        document.body.appendChild(successDiv);
        console.log('Success message added to DOM');
        
        // Debug: Log redirect
        console.log('=== REDIRECTING TO LOGIN ===');
        
        // Immediate redirect - no delay
        console.log('Immediate redirect to login.html');
        window.location.href = 'login.html';
    }
}

// Global functions
function selectAccountType(type) {
    if (type === 'admin') {
        document.getElementById('adminForm').style.display = 'flex';
    } else if (type === 'manager') {
        document.getElementById('managerForm').style.display = 'flex';
    } else if (type === 'support') {
        document.getElementById('supportForm').style.display = 'flex';
    }
}

function closeForm(formId) {
    document.getElementById(formId).style.display = 'none';
}

function togglePassword(fieldId) {
    const field = document.getElementById(fieldId);
    const icon = field.nextElementSibling.querySelector('i');
    
    if (field.type === 'password') {
        field.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        field.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Initialize the system
document.addEventListener('DOMContentLoaded', function() {
    window.medicalBookingSystem = new MedicalBookingSystem();
});
