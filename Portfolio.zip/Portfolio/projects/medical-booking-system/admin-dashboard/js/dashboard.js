// Dashboard JavaScript
class Dashboard {
    constructor() {
        this.currentUser = null;
        this.patients = [];
        this.appointments = [];
        this.doctors = [];
        this.initializeDashboard();
    }

    initializeDashboard() {
        this.loadCurrentUser();
        this.loadPatients();
        this.loadAppointments();
        this.loadDoctors();
        this.updateDateTime();
        this.initializeEventListeners();
        this.setupPermissions();
        
        // Update time every second
        setInterval(() => this.updateDateTime(), 1000);
    }

    loadCurrentUser() {
        const session = localStorage.getItem('medicalSession') || sessionStorage.getItem('medicalSession');
        if (session) {
            this.currentUser = JSON.parse(session).user;
            this.updateUserInfo();
        } else {
            // Redirect to login if no session
            window.location.href = 'login.html';
        }
    }

    updateUserInfo() {
        if (this.currentUser) {
            document.getElementById('userName').textContent = this.currentUser.fullName;
            document.getElementById('userRole').textContent = this.getRoleDisplayName(this.currentUser.role);
            
            // Update role badge
            const roleBadge = document.getElementById('userRoleBadge');
            if (roleBadge) {
                roleBadge.textContent = this.getRoleBadgeText(this.currentUser.role);
            }
            
            // Update permission text
            const permissionText = document.getElementById('permissionText');
            if (permissionText) {
                permissionText.textContent = this.getPermissionText(this.currentUser.role);
            }
        }
    }

    setupPermissions() {
        if (!this.currentUser) return;
        
        const role = this.currentUser.role;
        
        // Hide admin-only sections for non-admin users
        const adminOnlyElements = document.querySelectorAll('.admin-only');
        adminOnlyElements.forEach(element => {
            if (role === 'manager' || role === 'admin') {
                element.style.display = 'block';
            } else {
                element.style.display = 'none';
            }
        });
        
        // Update permission messages
        this.updatePermissionMessages(role);
    }

    updatePermissionMessages(role) {
        // Patient section permissions
        const patientDeletePermission = document.getElementById('patientDeletePermission');
        if (patientDeletePermission) {
            if (role === 'manager' || role === 'admin') {
                patientDeletePermission.textContent = 'يمكنك حذف المرضى.';
            } else {
                patientDeletePermission.textContent = 'حذف المرضى متاح فقط للمدير.';
            }
        }
        
        // Doctor section permissions
        const doctorManagePermission = document.getElementById('doctorManagePermission');
        if (doctorManagePermission) {
            if (role === 'manager' || role === 'admin') {
                doctorManagePermission.textContent = 'يمكنك إدارة الأطباء.';
            } else {
                doctorManagePermission.textContent = 'إضافة الأطباء متاحة فقط للمدير.';
            }
        }
    }

    getRoleDisplayName(role) {
        const roleNames = {
            'manager': 'مدير الموقع',
            'support': 'موظف الدعم',
            'admin': 'أدمن الموقع'
        };
        return roleNames[role] || 'موظف';
    }

    getRoleBadgeText(role) {
        const roleBadges = {
            'manager': 'Manager',
            'support': 'Support',
            'admin': 'Admin'
        };
        return roleBadges[role] || 'User';
    }

    getPermissionText(role) {
        const permissionTexts = {
            'manager': 'مدير الموقع - صلاحيات كاملة على النظام',
            'support': 'موظف الدعم - إدارة المرضى والحجوزات فقط',
            'admin': 'أدمن الموقع - صلاحيات كاملة وصيانة النظام'
        };
        return permissionTexts[role] || 'مستخدم - صلاحيات محدودة';
    }

    loadPatients() {
        const storedPatients = localStorage.getItem('medicalPatients');
        if (storedPatients) {
            this.patients = JSON.parse(storedPatients);
        } else {
            // Load sample data
            this.loadSamplePatients();
        }
        this.populatePatientsTable();
    }

    loadSamplePatients() {
        this.patients = [
            {
                id: 1,
                fullName: 'محمد أحمد عبدالله',
                phone: '0501234567',
                email: 'mohammed@email.com',
                birthDate: '1990-05-15',
                nationalId: '1234567890',
                address: 'الرياض، حي النخيل',
                lastVisit: '2024-01-20',
                status: 'active'
            },
            {
                id: 2,
                fullName: 'فاطمة علي محمد',
                phone: '0559876543',
                email: 'fatima@email.com',
                birthDate: '1985-08-22',
                nationalId: '0987654321',
                address: 'جدة، حي الروضة',
                lastVisit: '2024-01-18',
                status: 'active'
            },
            {
                id: 3,
                fullName: 'عمر خالد سعد',
                phone: '0562345678',
                email: 'omar@email.com',
                birthDate: '1992-12-10',
                nationalId: '1122334455',
                address: 'الدمام، حي الشاطئ',
                lastVisit: '2024-01-15',
                status: 'inactive'
            }
        ];
        localStorage.setItem('medicalPatients', JSON.stringify(this.patients));
    }

    loadAppointments() {
        const storedAppointments = localStorage.getItem('medicalAppointments');
        if (storedAppointments) {
            this.appointments = JSON.parse(storedAppointments);
        } else {
            // Load sample appointments
            this.loadSampleAppointments();
        }
    }

    loadDoctors() {
        const storedDoctors = localStorage.getItem('medicalDoctors');
        if (storedDoctors) {
            this.doctors = JSON.parse(storedDoctors);
        } else {
            // Load sample doctors
            this.loadSampleDoctors();
        }
        this.populateDoctorsTable();
    }

    loadSampleAppointments() {
        this.appointments = [
            {
                id: 1,
                patientId: 1,
                patientName: 'محمد أحمد',
                date: '2024-01-28',
                time: '09:00',
                type: 'فحص عام',
                status: 'confirmed',
                notes: 'مريض منتظم'
            },
            {
                id: 2,
                patientId: 2,
                patientName: 'فاطمة علي',
                date: '2024-01-28',
                time: '10:30',
                type: 'متابعة',
                status: 'pending',
                notes: 'متابعة حالة الضغط'
            },
            {
                id: 3,
                patientId: 3,
                patientName: 'عمر خالد',
                date: '2024-01-28',
                time: '11:45',
                type: 'استشارة',
                status: 'confirmed',
                notes: 'استشارة جديدة'
            }
        ];
        localStorage.setItem('medicalAppointments', JSON.stringify(this.appointments));
    }

    loadSampleDoctors() {
        this.doctors = [
            {
                id: 1,
                fullName: 'د. أحمد علي',
                specialization: 'طب عام',
                phone: '0501111111',
                email: 'dr.ahmed@medvibe.com',
                status: 'active',
                available: true,
                appointmentsToday: 8,
                experience: '10 سنوات'
            },
            {
                id: 2,
                fullName: 'د. سارة محمد',
                specialization: 'طب أطفال',
                phone: '0502222222',
                email: 'dr.sara@medvibe.com',
                status: 'active',
                available: true,
                appointmentsToday: 12,
                experience: '8 سنوات'
            },
            {
                id: 3,
                fullName: 'د. خالد أحمد',
                specialization: 'طب القلب',
                phone: '0503333333',
                email: 'dr.khaled@medvibe.com',
                status: 'active',
                available: false,
                appointmentsToday: 15,
                experience: '15 سنوات'
            }
        ];
        localStorage.setItem('medicalDoctors', JSON.stringify(this.doctors));
    }

    populatePatientsTable() {
        const tbody = document.getElementById('patientsTableBody');
        if (!tbody) return;

        tbody.innerHTML = '';
        
        this.patients.forEach(patient => {
            const row = document.createElement('tr');
            const canDelete = this.currentUser && (this.currentUser.role === 'manager' || this.currentUser.role === 'admin');
            
            row.innerHTML = `
                <td>${patient.fullName}</td>
                <td>${patient.phone}</td>
                <td>${patient.email || '-'}</td>
                <td>${this.formatDate(patient.birthDate)}</td>
                <td>${this.formatDate(patient.lastVisit)}</td>
                <td>
                    <span class="status-badge ${patient.status}">
                        ${patient.status === 'active' ? 'نشط' : 'غير نشط'}
                    </span>
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-icon" onclick="viewPatient(${patient.id})" title="عرض">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn-icon" onclick="editPatient(${patient.id})" title="تعديل">
                            <i class="fas fa-edit"></i>
                        </button>
                        ${canDelete ? `
                        <button class="btn-icon delete" onclick="deletePatient(${patient.id})" title="حذف">
                            <i class="fas fa-trash"></i>
                        </button>
                        ` : ''}
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    populateDoctorsTable() {
        const tbody = document.getElementById('doctorsTableBody');
        if (!tbody) return;

        tbody.innerHTML = '';
        
        this.doctors.forEach(doctor => {
            const row = document.createElement('tr');
            const canManage = this.currentUser && (this.currentUser.role === 'manager' || this.currentUser.role === 'admin');
            
            row.innerHTML = `
                <td>${doctor.fullName}</td>
                <td>${doctor.specialization}</td>
                <td>${doctor.phone}</td>
                <td>
                    <span class="status-badge ${doctor.available ? 'active' : 'inactive'}">
                        ${doctor.available ? 'متاح' : 'مشغول'}
                    </span>
                </td>
                <td>${doctor.appointmentsToday}</td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-icon" onclick="viewDoctor(${doctor.id})" title="عرض">
                            <i class="fas fa-eye"></i>
                        </button>
                        ${canManage ? `
                        <button class="btn-icon" onclick="editDoctor(${doctor.id})" title="تعديل">
                            <i class="fas fa-edit"></i>
                        </button>
                        ` : ''}
                    </div>
                </td>
            `;
            tbody.appendChild(row);
        });
    }

    formatDate(dateString) {
        if (!dateString) return '-';
        const date = new Date(dateString);
        return date.toLocaleDateString('ar-SA');
    }

    updateDateTime() {
        const now = new Date();
        const dateOptions = { year: 'numeric', month: 'long', day: 'numeric' };
        const timeOptions = { hour: '2-digit', minute: '2-digit', hour12: true };
        
        const currentDate = document.getElementById('currentDate');
        const currentTime = document.getElementById('currentTime');
        
        if (currentDate) {
            currentDate.textContent = now.toLocaleDateString('ar-SA', dateOptions);
        }
        
        if (currentTime) {
            currentTime.textContent = now.toLocaleTimeString('ar-SA', timeOptions);
        }
    }

    initializeEventListeners() {
        // Add patient form
        const addPatientForm = document.getElementById('addPatientForm');
        if (addPatientForm) {
            addPatientForm.addEventListener('submit', this.handleAddPatient.bind(this));
        }

        // Search functionality
        const searchInput = document.querySelector('.search-bar input');
        if (searchInput) {
            searchInput.addEventListener('input', this.handleSearch.bind(this));
        }

        // Close modals on outside click
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal(e.target.id);
            }
        });
    }

    handleAddPatient(event) {
        event.preventDefault();
        
        const formData = new FormData(event.target);
        const patient = {
            id: Date.now(),
            fullName: formData.get('fullName'),
            phone: formData.get('phone'),
            email: formData.get('email'),
            birthDate: formData.get('birthDate'),
            nationalId: formData.get('nationalId'),
            address: formData.get('address'),
            lastVisit: new Date().toISOString().split('T')[0],
            status: 'active'
        };

        this.patients.push(patient);
        localStorage.setItem('medicalPatients', JSON.stringify(this.patients));
        
        this.populatePatientsTable();
        this.closeModal('addPatientModal');
        this.showNotification('تم إضافة المريض بنجاح', 'success');
        
        event.target.reset();
    }

    handleSearch(event) {
        const searchTerm = event.target.value.toLowerCase();
        const rows = document.querySelectorAll('#patientsTableBody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    }

    viewPatient(id) {
        const patient = this.patients.find(p => p.id === id);
        if (patient) {
            // Show patient details modal
            console.log('View patient:', patient);
            // Implementation for view modal
        }
    }

    editPatient(id) {
        const patient = this.patients.find(p => p.id === id);
        if (patient) {
            // Show edit patient modal
            console.log('Edit patient:', patient);
            // Implementation for edit modal
        }
    }

    deletePatient(id) {
        if (confirm('هل أنت متأكد من حذف هذا المريض؟')) {
            this.patients = this.patients.filter(p => p.id !== id);
            localStorage.setItem('medicalPatients', JSON.stringify(this.patients));
            this.populatePatientsTable();
            this.showNotification('تم حذف المريض بنجاح', 'success');
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        `;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Remove after 3 seconds
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
}

// Global functions
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
        targetSection.classList.add('active');
    }
    
    // Update navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    event.target.closest('.nav-link').classList.add('active');
    
    // Update page title
    const titles = {
        'overview': 'نظرة عامة',
        'patients': 'إدارة المرضى',
        'appointments': 'إدارة الحجوزات',
        'staff': 'إدارة الموظفين',
        'reports': 'التقارير',
        'settings': 'الإعدادات'
    };
    
    document.getElementById('pageTitle').textContent = titles[sectionId] || 'لوحة التحكم';
}

function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    const mainContent = document.querySelector('.main-content');
    
    sidebar.classList.toggle('active');
    sidebar.classList.toggle('collapsed');
    mainContent.classList.toggle('expanded');
}

function openAddPatientModal() {
    document.getElementById('addPatientModal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function logout() {
    if (confirm('هل أنت متأكد من تسجيل الخروج؟')) {
        localStorage.removeItem('medicalSession');
        sessionStorage.removeItem('medicalSession');
        window.location.href = 'login.html';
    }
}

// Initialize dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    window.dashboard = new Dashboard();
    
    // Add notification styles
    const notificationStyles = `
        .notification {
            position: fixed;
            top: 20px;
            left: 20px;
            background: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            gap: 10px;
            z-index: 3000;
            animation: slideInRight 0.3s ease-out;
        }
        
        .notification.success {
            border-right: 4px solid #28a745;
            color: #28a745;
        }
        
        .notification.info {
            border-right: 4px solid #17a2b8;
            color: #17a2b8;
        }
        
        @keyframes slideInRight {
            from {
                opacity: 0;
                transform: translateX(100%);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .btn-icon {
            background: none;
            border: none;
            padding: 5px;
            margin: 0 2px;
            cursor: pointer;
            color: #666;
            border-radius: 4px;
            transition: all 0.3s ease;
        }
        
        .btn-icon:hover {
            background: #f8f9fa;
            color: #667eea;
        }
        
        .btn-icon.delete:hover {
            color: #dc3545;
        }
        
        .status-badge {
            padding: 4px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }
        
        .status-badge.active {
            background: #d4edda;
            color: #155724;
        }
        
        .status-badge.inactive {
            background: #f8d7da;
            color: #721c24;
        }
        
        .action-buttons {
            display: flex;
            gap: 5px;
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = notificationStyles;
    document.head.appendChild(styleSheet);
});
