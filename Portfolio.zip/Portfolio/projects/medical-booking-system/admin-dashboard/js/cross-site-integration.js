// Cross-Site Data Integration System
// ==================================

class CrossSiteIntegration {
    constructor() {
        this.apiEndpoint = 'http://localhost:8000/api/medical-data'; // MedVibe API
        this.webhookUrl = 'http://localhost:8000/webhook/medical-updates'; // MedVibe Webhook
        this.localDB = window.medicalDB;
        this.init();
    }

    async init() {
        console.log('🌐 Cross-Site Integration Initialized');
        console.log('📡 API Endpoint:', this.apiEndpoint);
        console.log('🔗 Webhook URL:', this.webhookUrl);
        
        // Start listening for data
        this.setupDataListeners();
        
        // Sync existing data
        await this.syncExistingData();
    }

    // Setup listeners for data changes
    setupDataListeners() {
        if (this.localDB) {
            // Listen for user changes
            this.localDB.onUsersChanged((users) => {
                this.broadcastData('users', users);
            });

            // Listen for patient changes
            this.localDB.onPatientsChanged((patients) => {
                this.broadcastData('patients', patients);
            });

            // Listen for appointment changes
            this.localDB.onAppointmentsChanged((appointments) => {
                this.broadcastData('appointments', appointments);
            });
        }
    }

    // Broadcast data to external site
    async broadcastData(type, data) {
        try {
            const payload = {
                type: type,
                data: data,
                timestamp: new Date().toISOString(),
                source: 'medical-booking-system',
                action: 'update'
            };

            // Send to webhook
            await this.sendWebhook(payload);
            
            // Also store locally for backup
            await this.storeIncomingData(type, data);
            
            console.log(`📤 Broadcasted ${type} data:`, data.length, 'items');
        } catch (error) {
            console.error('❌ Failed to broadcast data:', error);
        }
    }

    // Send webhook to external site
    async sendWebhook(payload) {
        try {
            const response = await fetch(this.webhookUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Source': 'medical-booking-system',
                    'X-Timestamp': new Date().toISOString()
                },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const result = await response.json();
            console.log('✅ Webhook sent successfully:', result);
            return result;
        } catch (error) {
            console.error('❌ Webhook failed:', error);
            // Store failed webhook for retry
            await this.storeFailedWebhook(payload);
            throw error;
        }
    }

    // Store incoming data from external site
    async storeIncomingData(type, data) {
        try {
            const incomingData = {
                type: type,
                data: data,
                timestamp: new Date().toISOString(),
                source: 'external-site'
            };

            // Store in local storage
            const existingData = JSON.parse(localStorage.getItem('crossSiteData') || '[]');
            existingData.push(incomingData);
            localStorage.setItem('crossSiteData', JSON.stringify(existingData));

            // Also store in database if available
            if (this.localDB) {
                await this.localDB.saveData(`crossSite_${type}`, incomingData);
            }

            console.log(`💾 Stored incoming ${type} data`);
        } catch (error) {
            console.error('❌ Failed to store incoming data:', error);
        }
    }

    // Receive data from external site
    async receiveData(type, data) {
        try {
            console.log(`📥 Receiving ${type} data from external site:`, data);

            // Process based on type
            switch (type) {
                case 'users':
                    await this.processUsersData(data);
                    break;
                case 'patients':
                    await this.processPatientsData(data);
                    break;
                case 'appointments':
                    await this.processAppointmentsData(data);
                    break;
                default:
                    console.log(`Unknown data type: ${type}`);
            }

            // Store in cross-site data
            await this.storeIncomingData(type, data);

            // Update dashboard
            this.updateDashboard(type, data);

            return { success: true };
        } catch (error) {
            console.error('❌ Failed to process incoming data:', error);
            return { success: false, error: error.message };
        }
    }

    // Process users data from external site
    async processUsersData(users) {
        if (!Array.isArray(users)) return;

        for (const user of users) {
            // Check if user already exists
            const existingUsers = await this.localDB.getAllUsers();
            const exists = existingUsers.find(u => u.email === user.email);

            if (!exists) {
                // Add new user
                await this.localDB.registerUser({
                    fullName: user.fullName || user.name,
                    email: user.email,
                    phone: user.phone,
                    password: user.password || 'default123',
                    role: user.role || 'support',
                    department: user.department,
                    level: user.level
                });
                console.log('➕ Added new user from external site:', user.email);
            }
        }
    }

    // Process patients data from external site
    async processPatientsData(patients) {
        if (!Array.isArray(patients)) return;

        for (const patient of patients) {
            // Add patient
            await this.localDB.addPatient({
                fullName: patient.fullName || patient.name,
                phone: patient.phone,
                email: patient.email,
                age: patient.age,
                address: patient.address,
                medicalHistory: patient.medicalHistory
            });
            console.log('➕ Added new patient from external site:', patient.fullName);
        }
    }

    // Process appointments data from external site
    async processAppointmentsData(appointments) {
        if (!Array.isArray(appointments)) return;

        for (const appointment of appointments) {
            // Add appointment
            await this.localDB.addAppointment({
                patientName: appointment.patientName,
                doctor: appointment.doctor,
                date: appointment.date,
                time: appointment.time,
                notes: appointment.notes,
                status: appointment.status || 'pending'
            });
            console.log('➕ Added new appointment from external site:', appointment.patientName);
        }
    }

    // Update dashboard with new data
    updateDashboard(type, data) {
        // Create notification
        const notification = {
            type: 'info',
            title: `بيانات جديدة من الموقع الخارجي`,
            message: `تم استلام ${data.length} ${this.getTypeLabel(type)} جديدة`,
            timestamp: new Date().toISOString(),
            data: data
        };

        // Store notification
        const notifications = JSON.parse(localStorage.getItem('notifications') || '[]');
        notifications.push(notification);
        localStorage.setItem('notifications', JSON.stringify(notifications));

        // Update UI if dashboard is open
        if (typeof updateDashboardUI === 'function') {
            updateDashboardUI(type, data);
        }

        console.log('📊 Dashboard updated with new data');
    }

    // Get Arabic label for type
    getTypeLabel(type) {
        const labels = {
            'users': 'مستخدمين',
            'patients': 'مرضى',
            'appointments': 'مواعيد'
        };
        return labels[type] || type;
    }

    // Sync existing data
    async syncExistingData() {
        try {
            console.log('🔄 Syncing existing data...');

            // Get all local data
            const [users, patients, appointments] = await Promise.all([
                this.localDB.getAllUsers(),
                this.localDB.getAllPatients(),
                this.localDB.getAllAppointments()
            ]);

            // Broadcast to external site
            await Promise.all([
                this.broadcastData('users', users),
                this.broadcastData('patients', patients),
                this.broadcastData('appointments', appointments)
            ]);

            console.log('✅ Existing data synced successfully');
        } catch (error) {
            console.error('❌ Failed to sync existing data:', error);
        }
    }

    // Store failed webhook for retry
    async storeFailedWebhook(payload) {
        const failedWebhooks = JSON.parse(localStorage.getItem('failedWebhooks') || '[]');
        failedWebhooks.push({
            payload: payload,
            timestamp: new Date().toISOString(),
            retryCount: 0
        });
        localStorage.setItem('failedWebhooks', JSON.stringify(failedWebhooks));
    }

    // Retry failed webhooks
    async retryFailedWebhooks() {
        const failedWebhooks = JSON.parse(localStorage.getItem('failedWebhooks') || '[]');
        const remaining = [];

        for (const webhook of failedWebhooks) {
            try {
                await this.sendWebhook(webhook.payload);
                console.log('✅ Retried webhook successfully');
            } catch (error) {
                webhook.retryCount++;
                if (webhook.retryCount < 3) {
                    remaining.push(webhook);
                }
            }
        }

        localStorage.setItem('failedWebhooks', JSON.stringify(remaining));
    }

    // Get cross-site statistics
    async getCrossSiteStats() {
        try {
            const crossSiteData = JSON.parse(localStorage.getItem('crossSiteData') || '[]');
            const failedWebhooks = JSON.parse(localStorage.getItem('failedWebhooks') || '[]');

            return {
                totalIncoming: crossSiteData.length,
                totalOutgoing: crossSiteData.filter(d => d.source === 'medical-booking-system').length,
                failedWebhooks: failedWebhooks.length,
                lastSync: localStorage.getItem('lastSyncTime'),
                status: 'active'
            };
        } catch (error) {
            return { error: error.message };
        }
    }

    // Manual sync trigger
    async manualSync() {
        console.log('🔄 Manual sync triggered...');
        await this.syncExistingData();
        await this.retryFailedWebhooks();
        localStorage.setItem('lastSyncTime', new Date().toISOString());
        return { success: true, message: 'Manual sync completed' };
    }
}

// Initialize cross-site integration
window.crossSiteIntegration = new CrossSiteIntegration();

// Make it available globally
window.receiveExternalData = async (type, data) => {
    return await window.crossSiteIntegration.receiveData(type, data);
};

// Manual sync function
window.manualSync = async () => {
    return await window.crossSiteIntegration.manualSync();
};

console.log('🌐 Cross-Site Integration Ready!');
console.log('📡 To receive data from external site, call: receiveExternalData(type, data)');
console.log('🔄 To manual sync, call: manualSync()');
