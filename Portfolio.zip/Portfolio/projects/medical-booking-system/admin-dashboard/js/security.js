// Advanced Security System for Medical Booking
class SecuritySystem {
    constructor() {
        this.encryptionKey = this.generateEncryptionKey();
        this.sessionTimeout = 30 * 60 * 1000; // 30 minutes
        this.maxLoginAttempts = 3;
        this.lockoutTime = 15 * 60 * 1000; // 15 minutes
    }

    // Generate encryption key
    generateEncryptionKey() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let key = '';
        for (let i = 0; i < 32; i++) {
            key += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return key;
    }

    // Advanced password hashing
    hashPassword(password, salt = null) {
        if (!salt) {
            salt = this.generateSalt();
        }
        
        // Combine password with salt
        const combined = password + salt;
        
        // Multiple hash rounds for security
        let hash = combined;
        for (let i = 0; i < 1000; i++) {
            hash = this.simpleHash(hash);
        }
        
        return {
            hash: hash,
            salt: salt
        };
    }

    // Simple hash function
    simpleHash(str) {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32-bit integer
        }
        return btoa(hash.toString());
    }

    // Generate random salt
    generateSalt() {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let salt = '';
        for (let i = 0; i < 16; i++) {
            salt += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return salt;
    }

    // Verify password with salt
    verifyPassword(inputPassword, storedHash, salt) {
        const { hash } = this.hashPassword(inputPassword, salt);
        return hash === storedHash;
    }

    // Check login attempts
    checkLoginAttempts(email) {
        const attempts = this.getLoginAttempts(email);
        const now = Date.now();
        
        // Check if user is locked out
        if (attempts.lockoutUntil && attempts.lockoutUntil > now) {
            const remainingTime = Math.ceil((attempts.lockoutUntil - now) / 60000);
            return {
                allowed: false,
                message: `تم حظر الحساب مؤقتاً. يرجى المحاولة بعد ${remainingTime} دقيقة`
            };
        }
        
        // Check if max attempts reached
        if (attempts.count >= this.maxLoginAttempts) {
            // Lock the account
            this.lockAccount(email);
            return {
                allowed: false,
                message: `تم حظر الحساب لمدة 15 دقيقة بسبب محاولات الدخول المتعددة`
            };
        }
        
        return { allowed: true };
    }

    // Get login attempts
    getLoginAttempts(email) {
        const key = `loginAttempts_${email}`;
        const stored = localStorage.getItem(key);
        return stored ? JSON.parse(stored) : { count: 0, lastAttempt: 0, lockoutUntil: 0 };
    }

    // Record failed login attempt
    recordFailedAttempt(email) {
        const key = `loginAttempts_${email}`;
        const attempts = this.getLoginAttempts(email);
        
        attempts.count++;
        attempts.lastAttempt = Date.now();
        
        localStorage.setItem(key, JSON.stringify(attempts));
    }

    // Reset login attempts on successful login
    resetLoginAttempts(email) {
        const key = `loginAttempts_${email}`;
        localStorage.removeItem(key);
    }

    // Lock account
    lockAccount(email) {
        const key = `loginAttempts_${email}`;
        const attempts = this.getLoginAttempts(email);
        
        attempts.lockoutUntil = Date.now() + this.lockoutTime;
        
        localStorage.setItem(key, JSON.stringify(attempts));
    }

    // Create secure session
    createSecureSession(userData, remember = false) {
        const session = {
            user: userData,
            loginTime: Date.now(),
            lastActivity: Date.now(),
            sessionId: this.generateSessionId(),
            secure: true,
            remember: remember
        };
        
        // Encrypt sensitive data
        const encryptedSession = this.encryptSession(session);
        
        // Store session
        const storage = remember ? localStorage : sessionStorage;
        storage.setItem('medicalSession', encryptedSession);
        
        return session;
    }

    // Generate session ID
    generateSessionId() {
        return 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    // Encrypt session data
    encryptSession(session) {
        // Simple encryption for demo (in production, use proper encryption)
        return JSON.stringify(session);
    }

    // Verify session
    verifySession() {
        const encryptedSession = localStorage.getItem('medicalSession') || sessionStorage.getItem('medicalSession');
        
        if (!encryptedSession) {
            return { valid: false, reason: 'No session found' };
        }
        
        try {
            const session = JSON.parse(encryptedSession);
            const now = Date.now();
            
            // Check session timeout
            if (!session.remember && (now - session.lastActivity) > this.sessionTimeout) {
                this.destroySession();
                return { valid: false, reason: 'Session expired' };
            }
            
            // Update last activity
            session.lastActivity = now;
            const storage = session.remember ? localStorage : sessionStorage;
            storage.setItem('medicalSession', JSON.stringify(session));
            
            return { valid: true, session: session };
            
        } catch (error) {
            console.error('Session verification error:', error);
            return { valid: false, reason: 'Invalid session' };
        }
    }

    // Destroy session
    destroySession() {
        localStorage.removeItem('medicalSession');
        sessionStorage.removeItem('medicalSession');
    }

    // Check if user has permission for action
    checkPermission(userRole, requiredPermission) {
        const permissions = {
            admin: ['all'],
            manager: ['manage_patients', 'manage_doctors', 'manage_appointments', 'view_reports'],
            support: ['manage_patients', 'manage_appointments', 'send_notifications']
        };
        
        if (userRole === 'admin') {
            return true;
        }
        
        return permissions[userRole] && permissions[userRole].includes(requiredPermission);
    }

    // Log security event
    logSecurityEvent(event, details = {}) {
        const log = {
            timestamp: new Date().toISOString(),
            event: event,
            details: details,
            userAgent: navigator.userAgent,
            ip: this.getClientIP()
        };
        
        console.log('Security Event:', log);
        
        // Store security logs (in production, send to server)
        const logs = JSON.parse(localStorage.getItem('securityLogs') || '[]');
        logs.push(log);
        
        // Keep only last 100 logs
        if (logs.length > 100) {
            logs.splice(0, logs.length - 100);
        }
        
        localStorage.setItem('securityLogs', JSON.stringify(logs));
    }

    // Get client IP (simplified)
    getClientIP() {
        return 'client'; // In production, get real IP
    }

    // Validate password strength
    validatePasswordStrength(password) {
        const checks = {
            length: password.length >= 8,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            numbers: /\d/.test(password),
            special: /[!@#$%^&*(),.?":{}|<>]/.test(password)
        };
        
        const score = Object.values(checks).filter(Boolean).length;
        
        return {
            score: score,
            checks: checks,
            strength: score <= 2 ? 'weak' : score <= 4 ? 'medium' : 'strong'
        };
    }
}

// Initialize security system
window.securitySystem = new SecuritySystem();
