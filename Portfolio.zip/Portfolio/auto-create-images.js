// Auto-create project images
const fs = require('fs');

// Create simple placeholder images
const createPlaceholderImage = (filename) => {
    // Create a simple 1x1 transparent PNG as placeholder
    const pngData = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
    fs.writeFileSync(`images/${filename}`, pngData);
    console.log(`Created: ${filename}`);
};

// Create all project images
try {
    if (!fs.existsSync('images')) {
        fs.mkdirSync('images');
    }
    
    createPlaceholderImage('royal-cafe-preview.png');
    createPlaceholderImage('medvibe-preview.png');
    createPlaceholderImage('calculator-preview.png');
    
    console.log('All project images created successfully!');
} catch (error) {
    console.error('Error creating images:', error);
}
