// Script to generate project preview images
function generateProjectImages() {
    const projects = [
        {
            name: 'royal-cafe',
            title: 'Royal Cafe',
            subtitle: 'القائمة الملكية',
            gradient: ['#FFD700', '#FFA500', '#FF6347'],
            icon: '👑',
            features: ['قائمة كافيه احترافية', 'تصميم ملكي فاخر', 'نظام فلترة متقدم']
        },
        {
            name: 'medical-booking',
            title: 'MedVibe',
            subtitle: 'النظام الطبي المتكامل',
            gradient: ['#667eea', '#764ba2'],
            icon: '🏥',
            features: ['حجز مواعيد ذكي', 'لوحة تحكم متقدمة', 'إدارة الأطباء والمرضى']
        },
        {
            name: 'calculator',
            title: 'آلة حاسبة ذكية',
            subtitle: 'Calculator App',
            gradient: ['#4CAF50', '#45a049'],
            icon: '🧮',
            features: ['عمليات حسابية أساسية', 'عمليات علمية متقدمة', 'سجل العمليات السابقة']
        }
    ];
    
    projects.forEach(project => {
        const canvas = document.createElement('canvas');
        canvas.width = 400;
        canvas.height = 300;
        const ctx = canvas.getContext('2d');
        
        // Create gradient background
        const gradient = ctx.createLinearGradient(0, 0, 400, 300);
        project.gradient.forEach((color, index) => {
            gradient.addColorStop(index / (project.gradient.length - 1), color);
        });
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, 400, 300);
        
        // Add icon
        ctx.font = '60px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(project.icon, 200, 100);
        
        // Add title
        ctx.fillStyle = 'white';
        ctx.font = 'bold 28px Cairo';
        ctx.fillText(project.title, 200, 160);
        
        // Add subtitle
        ctx.font = '18px Cairo';
        ctx.fillText(project.subtitle, 200, 190);
        
        // Add features
        ctx.font = '14px Cairo';
        project.features.forEach((feature, index) => {
            ctx.fillText(feature, 200, 220 + (index * 20));
        });
        
        // Download the image
        canvas.toBlob(function(blob) {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `${project.name}-preview.png`;
            a.click();
            URL.revokeObjectURL(url);
        });
    });
}

// Auto-generate images when page loads
window.addEventListener('load', generateProjectImages);
