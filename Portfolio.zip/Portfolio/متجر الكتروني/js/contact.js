// Contact page specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    initializeContactForm();
    initializeFAQ();
    initializeWhatsApp();
});

function initializeContactForm() {
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            const data = {};
            formData.forEach((value, key) => {
                data[key] = value;
            });
            
            // Validate form
            if (!validateContactForm(data)) {
                return;
            }
            
            // Show loading state
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'جاري الإرسال...';
            submitBtn.disabled = true;
            
            // Simulate form submission
            setTimeout(() => {
                showToast('تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.', 'success');
                this.reset();
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
            }, 2000);
        });
    }
}

function validateContactForm(data) {
    // Basic validation
    if (!data.firstName || !data.lastName || !data.email || !data.subject || !data.message) {
        showToast('يرجى ملء جميع الحقول المطلوبة', 'error');
        return false;
    }
    
    // Email validation
    if (!isValidEmail(data.email)) {
        showToast('البريد الإلكتروني غير صحيح', 'error');
        return false;
    }
    
    // Phone validation (if provided)
    if (data.phone && !isValidPhone(data.phone)) {
        showToast('رقم الهاتف غير صحيح', 'error');
        return false;
    }
    
    // Message length validation
    if (data.message.length < 10) {
        showToast('الرسالة يجب أن تحتوي على 10 أحرف على الأقل', 'error');
        return false;
    }
    
    return true;
}

function initializeFAQ() {
    const faqItems = document.querySelectorAll('.faq-item');
    
    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        
        question.addEventListener('click', function() {
            const isActive = item.classList.contains('active');
            
            // Close all FAQ items
            faqItems.forEach(faqItem => {
                faqItem.classList.remove('active');
                faqItem.querySelector('.faq-answer').style.maxHeight = '0';
                faqItem.querySelector('.fas').classList.remove('fa-chevron-up');
                faqItem.querySelector('.fas').classList.add('fa-chevron-down');
            });
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                item.classList.add('active');
                answer.style.maxHeight = answer.scrollHeight + 'px';
                item.querySelector('.fas').classList.remove('fa-chevron-down');
                item.querySelector('.fas').classList.add('fa-chevron-up');
            }
        });
    });
}

function initializeWhatsApp() {
    const whatsappBtn = document.querySelector('.btn-whatsapp');
    if (whatsappBtn) {
        whatsappBtn.addEventListener('click', function() {
            const phoneNumber = '+966501234567';
            const message = 'مرحباً، أود الاستفسار عن...';
            const whatsappUrl = `https://wa.me/${phoneNumber.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(message)}`;
            window.open(whatsappUrl, '_blank');
        });
    }
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
    return /^(\+966|0)?5[0-9]{8}$/.test(phone.replace(/\s/g, ''));
}

// Add CSS for contact page
const contactCSS = `
/* Page Header */
.page-header {
    background: linear-gradient(135deg, #34495e 0%, #2c3e50 100%);
    color: white;
    padding: 6rem 0 3rem;
    text-align: center;
    margin-top: 80px;
}

.page-header h1 {
    font-size: 2.5rem;
    margin-bottom: 1rem;
}

.page-header p {
    font-size: 1.2rem;
    opacity: 0.9;
}

/* Contact Section */
.contact-section {
    padding: 4rem 0;
    background: #f8f9fa;
}

.contact-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 3rem;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.contact-form-wrapper {
    background: white;
    padding: 2.5rem;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.contact-form-wrapper h2 {
    font-size: 1.8rem;
    margin-bottom: 2rem;
    color: #2c3e50;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #333;
}

.form-group input,
.form-group select,
.form-group textarea {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.3s;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
    outline: none;
    border-color: #3498db;
}

.form-group textarea {
    resize: vertical;
    min-height: 120px;
}

.checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-weight: normal;
}

.checkbox-label input {
    width: auto;
    margin-left: 0.5rem;
}

/* Contact Info */
.contact-info {
    background: white;
    padding: 2.5rem;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.contact-info h2 {
    font-size: 1.8rem;
    margin-bottom: 2rem;
    color: #2c3e50;
}

.contact-item {
    display: flex;
    align-items: flex-start;
    gap: 1.5rem;
    margin-bottom: 2rem;
    padding-bottom: 2rem;
    border-bottom: 1px solid #eee;
}

.contact-item:last-child {
    border-bottom: none;
    margin-bottom: 0;
    padding-bottom: 0;
}

.contact-icon {
    width: 50px;
    height: 50px;
    background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.2rem;
    flex-shrink: 0;
}

.contact-details h3 {
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
    color: #333;
}

.contact-details p {
    color: #666;
    margin-bottom: 0.25rem;
}

.btn-whatsapp {
    background: #25d366;
    color: white;
    border: none;
    padding: 0.5rem 1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
    margin-top: 0.5rem;
}

.btn-whatsapp:hover {
    background: #128c7e;
}

/* Map Section */
.map-section {
    padding: 4rem 0;
    background: white;
}

.map-section h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 2rem;
    color: #2c3e50;
}

.map-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    border-radius: 15px;
    overflow: hidden;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

/* FAQ Section */
.faq-section {
    padding: 4rem 0;
    background: #f8f9fa;
}

.faq-section h2 {
    text-align: center;
    font-size: 2rem;
    margin-bottom: 3rem;
    color: #2c3e50;
}

.faq-container {
    max-width: 800px;
    margin: 0 auto;
    padding: 0 20px;
}

.faq-item {
    background: white;
    border-radius: 10px;
    margin-bottom: 1rem;
    overflow: hidden;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.faq-question {
    padding: 1.5rem;
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    transition: background 0.3s;
}

.faq-question:hover {
    background: #f8f9fa;
}

.faq-question h3 {
    font-size: 1.1rem;
    color: #333;
    margin: 0;
}

.faq-question i {
    color: #3498db;
    transition: transform 0.3s;
}

.faq-answer {
    max-height: 0;
    overflow: hidden;
    transition: max-height 0.3s ease;
}

.faq-answer p {
    padding: 0 1.5rem 1.5rem;
    color: #666;
    line-height: 1.6;
    margin: 0;
}

.faq-item.active .faq-question {
    background: #f8f9fa;
    border-bottom: 1px solid #eee;
}

.faq-item.active .faq-question i {
    transform: rotate(180deg);
}

/* Categories Page Styles */
.categories-page {
    padding: 4rem 0;
    background: #f8f9fa;
}

.categories-full-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 2rem;
    margin-bottom: 4rem;
}

.category-card-large {
    position: relative;
    border-radius: 20px;
    overflow: hidden;
    cursor: pointer;
    transition: transform 0.3s, box-shadow 0.3s;
    height: 400px;
}

.category-card-large:hover {
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.2);
}

.category-image {
    position: relative;
    width: 100%;
    height: 100%;
}

.category-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s;
}

.category-card-large:hover .category-image img {
    transform: scale(1.1);
}

.category-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, rgba(44, 62, 80, 0.9) 0%, rgba(52, 73, 94, 0.8) 100%);
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    text-align: center;
    padding: 2rem;
}

.category-content i {
    font-size: 3rem;
    margin-bottom: 1rem;
    color: #3498db;
}

.category-content h3 {
    font-size: 1.8rem;
    margin-bottom: 1rem;
}

.category-content p {
    margin-bottom: 1.5rem;
    opacity: 0.9;
    line-height: 1.6;
}

.category-stats {
    display: flex;
    justify-content: center;
    gap: 2rem;
    margin-bottom: 2rem;
}

.category-stats span {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
}

.category-stats i {
    font-size: 1rem;
    color: #3498db;
}

.featured-categories {
    text-align: center;
}

.featured-categories h2 {
    font-size: 2rem;
    margin-bottom: 3rem;
    color: #2c3e50;
}

.featured-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 2rem;
}

.featured-category {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    text-align: center;
    transition: transform 0.3s, box-shadow 0.3s;
    cursor: pointer;
}

.featured-category:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.featured-icon {
    width: 80px;
    height: 80px;
    background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 1rem;
    color: white;
    font-size: 2rem;
}

.featured-category h4 {
    font-size: 1.2rem;
    margin-bottom: 0.5rem;
    color: #333;
}

.featured-category p {
    color: #666;
    font-size: 0.9rem;
}

/* Responsive Design */
@media (max-width: 768px) {
    .contact-container {
        grid-template-columns: 1fr;
        gap: 2rem;
    }
    
    .form-row {
        grid-template-columns: 1fr;
    }
    
    .categories-full-grid {
        grid-template-columns: 1fr;
    }
    
    .featured-grid {
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    }
    
    .category-stats {
        flex-direction: column;
        gap: 0.5rem;
    }
    
    .contact-item {
        flex-direction: column;
        text-align: center;
    }
    
    .contact-icon {
        margin: 0 auto;
    }
}

@media (max-width: 480px) {
    .page-header h1 {
        font-size: 2rem;
    }
    
    .contact-form-wrapper,
    .contact-info {
        padding: 1.5rem;
    }
    
    .category-card-large {
        height: 300px;
    }
    
    .category-content {
        padding: 1rem;
    }
    
    .category-content h3 {
        font-size: 1.5rem;
    }
}
`;

// Add the CSS to the page
const styleSheet = document.createElement('style');
styleSheet.textContent = contactCSS;
document.head.appendChild(styleSheet);
