// Checkout page specific JavaScript
let currentStep = 1;
const totalSteps = 4;
let orderData = {
    shipping: {},
    payment: {},
    items: [],
    totals: {}
};

// Initialize checkout page
document.addEventListener('DOMContentLoaded', function() {
    loadCartItems();
    initializeCheckout();
    setupEventListeners();
    updateOrderSummary();
});

function initializeCheckout() {
    // Load cart from localStorage
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        orderData.items = JSON.parse(savedCart);
    }
    
    // If cart is empty, redirect to products page
    if (orderData.items.length === 0) {
        showToast('السلة فارغة! يرجى إضافة منتجات أولاً.', 'error');
        setTimeout(() => {
            window.location.href = 'products.html';
        }, 2000);
        return;
    }
    
    updateStepDisplay();
}

function setupEventListeners() {
    // Form navigation
    document.getElementById('next-btn').addEventListener('click', nextStep);
    document.getElementById('prev-btn').addEventListener('click', prevStep);
    document.getElementById('checkout-form').addEventListener('submit', placeOrder);
    
    // Payment method change
    document.querySelectorAll('input[name="paymentMethod"]').forEach(radio => {
        radio.addEventListener('change', handlePaymentMethodChange);
    });
    
    // Credit card formatting
    const cardNumberInput = document.getElementById('cardNumber');
    if (cardNumberInput) {
        cardNumberInput.addEventListener('input', formatCardNumber);
    }
    
    const expiryDateInput = document.getElementById('expiryDate');
    if (expiryDateInput) {
        expiryDateInput.addEventListener('input', formatExpiryDate);
    }
    
    const cvvInput = document.getElementById('cvv');
    if (cvvInput) {
        cvvInput.addEventListener('input', formatCVV);
    }
    
    // Promo code
    document.getElementById('apply-promo').addEventListener('click', applyPromoCode);
    
    // Form validation
    const form = document.getElementById('checkout-form');
    const inputs = form.querySelectorAll('input[required], select[required]');
    inputs.forEach(input => {
        input.addEventListener('blur', () => validateField(input));
        input.addEventListener('input', () => clearFieldError(input));
    });
}

function updateStepDisplay() {
    // Update step indicators
    document.querySelectorAll('.checkout-steps .step').forEach((step, index) => {
        if (index + 1 < currentStep) {
            step.classList.add('completed');
            step.classList.remove('active');
        } else if (index + 1 === currentStep) {
            step.classList.add('active');
            step.classList.remove('completed');
        } else {
            step.classList.remove('active', 'completed');
        }
    });
    
    // Show/hide sections
    document.querySelectorAll('.form-section').forEach(section => {
        section.style.display = 'none';
    });
    
    const currentSection = document.getElementById(getSectionId(currentStep));
    if (currentSection) {
        currentSection.style.display = 'block';
    }
    
    // Update navigation buttons
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const placeOrderBtn = document.getElementById('place-order-btn');
    
    prevBtn.style.display = currentStep === 1 ? 'none' : 'block';
    
    if (currentStep === totalSteps) {
        nextBtn.style.display = 'none';
        placeOrderBtn.style.display = 'block';
    } else {
        nextBtn.style.display = 'block';
        placeOrderBtn.style.display = 'none';
    }
}

function getSectionId(step) {
    const sections = {
        1: 'shipping-section',
        2: 'payment-section',
        3: 'review-section',
        4: 'confirmation-section'
    };
    return sections[step];
}

function nextStep() {
    if (validateCurrentStep()) {
        saveCurrentStepData();
        
        if (currentStep < totalSteps) {
            currentStep++;
            
            // Special handling for review step
            if (currentStep === 3) {
                populateReviewSection();
            }
            
            updateStepDisplay();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }
}

function prevStep() {
    if (currentStep > 1) {
        currentStep--;
        updateStepDisplay();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

function validateCurrentStep() {
    const currentSection = document.getElementById(getSectionId(currentStep));
    const requiredFields = currentSection.querySelectorAll('input[required], select[required]');
    
    for (let field of requiredFields) {
        if (!validateField(field)) {
            field.focus();
            return false;
        }
    }
    
    return true;
}

function validateField(field) {
    const value = field.value.trim();
    let isValid = true;
    let errorMessage = '';
    
    clearFieldError(field);
    
    if (field.hasAttribute('required') && !value) {
        isValid = false;
        errorMessage = 'هذا الحقل مطلوب';
    } else if (field.type === 'email' && value && !isValidEmail(value)) {
        isValid = false;
        errorMessage = 'البريد الإلكتروني غير صحيح';
    } else if (field.type === 'tel' && value && !isValidPhone(value)) {
        isValid = false;
        errorMessage = 'رقم الهاتف غير صحيح';
    } else if (field.id === 'cardNumber' && value && !isValidCardNumber(value)) {
        isValid = false;
        errorMessage = 'رقم البطاقة غير صحيح';
    } else if (field.id === 'expiryDate' && value && !isValidExpiryDate(value)) {
        isValid = false;
        errorMessage = 'تاريخ الانتهاء غير صحيح';
    } else if (field.id === 'cvv' && value && !isValidCVV(value)) {
        isValid = false;
        errorMessage = 'CVV غير صحيح';
    }
    
    if (!isValid) {
        showFieldError(field, errorMessage);
    }
    
    return isValid;
}

function showFieldError(field, message) {
    field.classList.add('error');
    
    let errorElement = field.parentNode.querySelector('.error-message');
    if (!errorElement) {
        errorElement = document.createElement('div');
        errorElement.className = 'error-message';
        field.parentNode.appendChild(errorElement);
    }
    
    errorElement.textContent = message;
}

function clearFieldError(field) {
    field.classList.remove('error');
    const errorElement = field.parentNode.querySelector('.error-message');
    if (errorElement) {
        errorElement.remove();
    }
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
    return /^(\+966|0)?5[0-9]{8}$/.test(phone.replace(/\s/g, ''));
}

function isValidCardNumber(number) {
    const cleaned = number.replace(/\s/g, '');
    return /^\d{16}$/.test(cleaned) && luhnCheck(cleaned);
}

function luhnCheck(cardNumber) {
    let sum = 0;
    let isEven = false;
    
    for (let i = cardNumber.length - 1; i >= 0; i--) {
        let digit = parseInt(cardNumber[i]);
        
        if (isEven) {
            digit *= 2;
            if (digit > 9) {
                digit -= 9;
            }
        }
        
        sum += digit;
        isEven = !isEven;
    }
    
    return sum % 10 === 0;
}

function isValidExpiryDate(date) {
    const regex = /^(0[1-9]|1[0-2])\/\d{2}$/;
    if (!regex.test(date)) return false;
    
    const [month, year] = date.split('/').map(Number);
    const currentYear = new Date().getFullYear() % 100;
    const currentMonth = new Date().getMonth() + 1;
    
    if (year < currentYear || (year === currentYear && month < currentMonth)) {
        return false;
    }
    
    return true;
}

function isValidCVV(cvv) {
    return /^\d{3,4}$/.test(cvv);
}

function formatCardNumber(e) {
    let value = e.target.value.replace(/\s/g, '');
    let formattedValue = '';
    
    for (let i = 0; i < value.length; i++) {
        if (i > 0 && i % 4 === 0) {
            formattedValue += ' ';
        }
        formattedValue += value[i];
    }
    
    e.target.value = formattedValue;
}

function formatExpiryDate(e) {
    let value = e.target.value.replace(/\D/g, '');
    
    if (value.length >= 2) {
        value = value.slice(0, 2) + '/' + value.slice(2, 4);
    }
    
    e.target.value = value;
}

function formatCVV(e) {
    e.target.value = e.target.value.replace(/\D/g, '');
}

function handlePaymentMethodChange(e) {
    const creditCardForm = document.getElementById('credit-card-form');
    const selectedMethod = e.target.value;
    
    if (selectedMethod === 'credit-card' || selectedMethod === 'mada') {
        creditCardForm.style.display = 'block';
        // Make credit card fields required
        creditCardForm.querySelectorAll('input').forEach(input => {
            input.setAttribute('required', 'required');
        });
    } else {
        creditCardForm.style.display = 'none';
        // Remove required from credit card fields
        creditCardForm.querySelectorAll('input').forEach(input => {
            input.removeAttribute('required');
        });
    }
}

function saveCurrentStepData() {
    switch(currentStep) {
        case 1:
            saveShippingData();
            break;
        case 2:
            savePaymentData();
            break;
    }
}

function saveShippingData() {
    const form = document.getElementById('checkout-form');
    const formData = new FormData(form);
    
    orderData.shipping = {
        firstName: formData.get('firstName'),
        lastName: formData.get('lastName'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        address: formData.get('address'),
        city: formData.get('city'),
        postalCode: formData.get('postalCode'),
        saveAddress: formData.get('saveAddress') === 'on'
    };
}

function savePaymentData() {
    const form = document.getElementById('checkout-form');
    const formData = new FormData(form);
    
    orderData.payment = {
        method: formData.get('paymentMethod'),
        cardNumber: formData.get('cardNumber'),
        expiryDate: formData.get('expiryDate'),
        cvv: formData.get('cvv'),
        cardName: formData.get('cardName')
    };
}

function populateReviewSection() {
    // Shipping address
    const shippingReview = document.querySelector('.shipping-address-review');
    shippingReview.innerHTML = `
        <p><strong>${orderData.shipping.firstName} ${orderData.shipping.lastName}</strong></p>
        <p>${orderData.shipping.address}</p>
        <p>${orderData.shipping.city}, ${orderData.shipping.postalCode || ''}</p>
        <p>📱 ${orderData.shipping.phone}</p>
        <p>✉️ ${orderData.shipping.email}</p>
    `;
    
    // Payment method
    const paymentReview = document.querySelector('.payment-method-review');
    const paymentMethods = {
        'credit-card': 'بطاقة ائتمانية',
        'mada': 'مدى',
        'apple-pay': 'Apple Pay',
        'cash-on-delivery': 'الدفع عند الاستلام'
    };
    
    paymentReview.innerHTML = `
        <p><strong>${paymentMethods[orderData.payment.method] || 'غير محدد'}</strong></p>
        ${orderData.payment.cardNumber ? `<p>**** **** **** ${orderData.payment.cardNumber.slice(-4)}</p>` : ''}
    `;
    
    // Order items
    const itemsReview = document.querySelector('.order-items-review');
    itemsReview.innerHTML = orderData.items.map(item => `
        <div class="review-item">
            <div class="review-item-info">
                <h4>${item.name}</h4>
                <p>الكمية: ${item.quantity}</p>
            </div>
            <div class="review-item-price">
                <span>${(item.price * item.quantity).toFixed(2)} ريال</span>
            </div>
        </div>
    `).join('');
}

function placeOrder(e) {
    e.preventDefault();
    
    if (!validateCurrentStep()) {
        return;
    }
    
    // Show loading state
    const submitBtn = document.getElementById('place-order-btn');
    const originalText = submitBtn.textContent;
    submitBtn.textContent = 'جاري المعالجة...';
    submitBtn.disabled = true;
    
    // Simulate order processing
    setTimeout(() => {
        // Generate order number
        const orderNumber = '#' + Math.floor(10000 + Math.random() * 90000);
        document.getElementById('order-number').textContent = orderNumber;
        
        // Save order to localStorage (in real app, this would be sent to server)
        const order = {
            number: orderNumber,
            date: new Date().toISOString(),
            ...orderData,
            totals: calculateTotals()
        };
        
        localStorage.setItem('lastOrder', JSON.stringify(order));
        
        // Clear cart
        localStorage.removeItem('cart');
        
        // Move to confirmation step
        currentStep = 4;
        updateStepDisplay();
        
        // Reset button
        submitBtn.textContent = originalText;
        submitBtn.disabled = false;
        
        // Show success message
        showToast('تم تأكيد طلبك بنجاح!', 'success');
        
        // Update cart count in header
        if (typeof updateCartUI === 'function') {
            updateCartUI();
        }
        
    }, 2000);
}

function loadCartItems() {
    const summaryItems = document.getElementById('summary-items');
    const savedCart = localStorage.getItem('cart');
    
    if (savedCart) {
        const cart = JSON.parse(savedCart);
        summaryItems.innerHTML = cart.map(item => `
            <div class="summary-item">
                <div class="summary-item-info">
                    <h4>${item.name}</h4>
                    <p>الكمية: ${item.quantity}</p>
                </div>
                <div class="summary-item-price">
                    <span>${(item.price * item.quantity).toFixed(2)} ريال</span>
                </div>
            </div>
        `).join('');
    } else {
        summaryItems.innerHTML = '<p>السلة فارغة</p>';
    }
}

function updateOrderSummary() {
    const totals = calculateTotals();
    
    document.getElementById('subtotal').textContent = totals.subtotal.toFixed(2) + ' ريال';
    document.getElementById('shipping').textContent = totals.shipping.toFixed(2) + ' ريال';
    document.getElementById('tax').textContent = totals.tax.toFixed(2) + ' ريال';
    document.getElementById('total').textContent = totals.total.toFixed(2) + ' ريال';
    
    if (totals.discount > 0) {
        document.getElementById('discount').textContent = '-' + totals.discount.toFixed(2) + ' ريال';
        document.querySelector('.discount-row').style.display = 'flex';
    } else {
        document.querySelector('.discount-row').style.display = 'none';
    }
}

function calculateTotals() {
    const savedCart = localStorage.getItem('cart');
    let subtotal = 0;
    
    if (savedCart) {
        const cart = JSON.parse(savedCart);
        subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    }
    
    const shipping = subtotal > 500 ? 0 : 30;
    const tax = subtotal * 0.15;
    const discount = 0; // Will be updated when promo is applied
    const total = subtotal + shipping + tax - discount;
    
    return {
        subtotal,
        shipping,
        tax,
        discount,
        total
    };
}

function applyPromoCode() {
    const promoInput = document.getElementById('promo-code');
    const promoCode = promoInput.value.trim().toUpperCase();
    
    if (!promoCode) {
        showToast('يرجى إدخال كود الخصم', 'error');
        return;
    }
    
    // Simulate promo code validation
    const validPromos = {
        'SAVE10': 0.1,
        'SAVE20': 0.2,
        'WELCOME': 0.15
    };
    
    if (validPromos[promoCode]) {
        const totals = calculateTotals();
        const discount = totals.subtotal * validPromos[promoCode];
        
        // Update totals with discount
        totals.discount = discount;
        totals.total = totals.subtotal + totals.shipping + totals.tax - discount;
        
        // Update display
        document.getElementById('discount').textContent = '-' + discount.toFixed(2) + ' ريال';
        document.querySelector('.discount-row').style.display = 'flex';
        document.getElementById('total').textContent = totals.total.toFixed(2) + ' ريال';
        
        showToast('تم تطبيق كود الخصم بنجاح!', 'success');
        promoInput.disabled = true;
        document.getElementById('apply-promo').disabled = true;
    } else {
        showToast('كود الخصم غير صحيح', 'error');
    }
}

// Add checkout-specific CSS
const checkoutCSS = `
.checkout-section {
    padding: 2rem 0;
    background: #f8f9fa;
    min-height: 60vh;
}

.checkout-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.checkout-steps {
    display: flex;
    justify-content: center;
    margin-bottom: 3rem;
    gap: 2rem;
}

.step {
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
}

.step:not(:last-child)::after {
    content: '';
    position: absolute;
    top: 20px;
    left: 100%;
    width: 2rem;
    height: 2px;
    background: #ddd;
    margin-left: 1rem;
}

.step.completed::after {
    background: #667eea;
}

.step-number {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background: #ddd;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: bold;
    margin-bottom: 0.5rem;
    transition: all 0.3s;
}

.step.active .step-number {
    background: #667eea;
    transform: scale(1.1);
}

.step.completed .step-number {
    background: #4caf50;
}

.step-title {
    font-size: 0.9rem;
    color: #666;
    text-align: center;
}

.step.active .step-title {
    color: #667eea;
    font-weight: bold;
}

.step.completed .step-title {
    color: #4caf50;
}

.checkout-content {
    display: grid;
    grid-template-columns: 1fr 400px;
    gap: 2rem;
}

.checkout-form {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
}

.form-section {
    margin-bottom: 2rem;
}

.form-section h3 {
    margin-bottom: 1.5rem;
    color: #333;
    font-size: 1.3rem;
}

.form-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 1rem;
}

.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 500;
    color: #333;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 1rem;
    transition: border-color 0.3s;
}

.form-group input:focus,
.form-group select:focus {
    outline: none;
    border-color: #667eea;
}

.form-group input.error,
.form-group select.error {
    border-color: #f44336;
}

.error-message {
    color: #f44336;
    font-size: 0.8rem;
    margin-top: 0.25rem;
}

.checkbox-label {
    display: flex;
    align-items: center;
    cursor: pointer;
    font-weight: normal;
}

.checkbox-label input {
    width: auto;
    margin-left: 0.5rem;
}

.payment-methods {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-bottom: 2rem;
}

.payment-method {
    border: 2px solid #ddd;
    border-radius: 10px;
    transition: border-color 0.3s;
}

.payment-method:hover {
    border-color: #667eea;
}

.payment-method input[type="radio"] {
    display: none;
}

.payment-method input[type="radio"]:checked + .radio-label {
    border-color: #667eea;
    background: rgba(102, 126, 234, 0.1);
}

.radio-label {
    display: flex;
    align-items: center;
    padding: 1rem;
    border-radius: 8px;
    cursor: pointer;
    transition: all 0.3s;
}

.payment-option {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.payment-option i {
    font-size: 1.2rem;
    color: #667eea;
}

.credit-card-form {
    background: #f8f9fa;
    padding: 1.5rem;
    border-radius: 10px;
    margin-top: 1rem;
}

.order-summary {
    background: white;
    padding: 1.5rem;
    border-radius: 10px;
    margin-bottom: 1.5rem;
}

.order-summary h4 {
    margin-bottom: 1rem;
    color: #333;
}

.shipping-address-review,
.payment-method-review {
    background: #f8f9fa;
    padding: 1rem;
    border-radius: 8px;
    margin-bottom: 1rem;
}

.review-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 0;
    border-bottom: 1px solid #eee;
}

.review-item:last-child {
    border-bottom: none;
}

.order-confirmation {
    text-align: center;
    padding: 2rem;
}

.success-icon {
    font-size: 4rem;
    color: #4caf50;
    margin-bottom: 1rem;
}

.order-confirmation h3 {
    color: #333;
    margin-bottom: 1rem;
}

.order-confirmation p {
    color: #666;
    margin-bottom: 0.5rem;
}

.confirmation-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
    margin-top: 2rem;
}

.btn-secondary {
    background: #6c757d;
    color: white;
    padding: 0.75rem 1.5rem;
    border: none;
    border-radius: 25px;
    cursor: pointer;
    transition: background 0.3s;
}

.btn-secondary:hover {
    background: #5a6268;
}

.form-navigation {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 2rem;
    padding-top: 2rem;
    border-top: 1px solid #eee;
}

.order-summary-sidebar {
    background: white;
    padding: 2rem;
    border-radius: 15px;
    box-shadow: 0 5px 20px rgba(0,0,0,0.1);
    height: fit-content;
    position: sticky;
    top: 100px;
}

.order-summary-sidebar h3 {
    margin-bottom: 1.5rem;
    color: #333;
}

.summary-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem 0;
    border-bottom: 1px solid #eee;
}

.summary-item:last-child {
    border-bottom: none;
}

.summary-item-info h4 {
    font-size: 0.9rem;
    margin-bottom: 0.25rem;
}

.summary-item-info p {
    font-size: 0.8rem;
    color: #666;
}

.summary-item-price {
    font-weight: bold;
    color: #333;
}

.summary-totals {
    margin: 1.5rem 0;
    padding: 1rem 0;
    border-top: 1px solid #eee;
}

.summary-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 0.5rem;
}

.total-row {
    font-weight: bold;
    font-size: 1.2rem;
    color: #667eea;
    padding-top: 0.5rem;
    border-top: 2px solid #eee;
}

.discount-row {
    color: #4caf50;
}

.promo-code {
    display: flex;
    gap: 0.5rem;
    margin-bottom: 1.5rem;
}

.promo-code input {
    flex: 1;
    padding: 0.75rem;
    border: 1px solid #ddd;
    border-radius: 8px;
}

.promo-code button {
    padding: 0.75rem 1.5rem;
    background: #667eea;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
}

.promo-code button:hover:not(:disabled) {
    background: #5a67d8;
}

.promo-code button:disabled {
    background: #ccc;
    cursor: not-allowed;
}

.security-info {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: #666;
    font-size: 0.9rem;
    text-align: center;
}

.security-info i {
    color: #4caf50;
}

@media (max-width: 768px) {
    .checkout-content {
        grid-template-columns: 1fr;
    }
    
    .checkout-steps {
        flex-direction: column;
        gap: 1rem;
    }
    
    .step:not(:last-child)::after {
        display: none;
    }
    
    .form-row {
        grid-template-columns: 1fr;
    }
    
    .payment-methods {
        grid-template-columns: 1fr;
    }
    
    .order-summary-sidebar {
        position: static;
    }
    
    .confirmation-actions {
        flex-direction: column;
    }
}
`;

// Add the CSS to the page
const styleSheet = document.createElement('style');
styleSheet.textContent = checkoutCSS;
document.head.appendChild(styleSheet);
