// Shopping Cart functionality
let cart = [];
let cartCount = 0;
let wishlist = [];

// DOM Elements
const cartIcon = document.querySelector('.cart-icon');
const cartSidebar = document.querySelector('.cart-sidebar');
const closeCart = document.querySelector('.close-cart');
const cartItemsContainer = document.querySelector('.cart-items');
const cartCountElement = document.querySelector('.cart-count');
const totalPriceElement = document.querySelector('.total-price');
const overlay = document.createElement('div');
overlay.className = 'overlay';
document.body.appendChild(overlay);

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadCartFromStorage();
    updateCartUI();
    initializeEventListeners();
    initializeAnimations();
});

// Initialize scroll to top button
function initializeScrollToTop() {
    const scrollToTopBtn = document.createElement('button');
    scrollToTopBtn.className = 'scroll-to-top';
    scrollToTopBtn.innerHTML = '<i class="fas fa-arrow-up"></i>';
    scrollToTopBtn.setAttribute('aria-label', 'العودة للأعلى');
    document.body.appendChild(scrollToTopBtn);
    
    // Show/hide button based on scroll position
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollToTopBtn.classList.add('visible');
        } else {
            scrollToTopBtn.classList.remove('visible');
        }
    });
    
    // Scroll to top when clicked
    scrollToTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Initialize mobile menu
function initializeMobileMenu() {
    const mobileMenuToggle = document.createElement('button');
    mobileMenuToggle.className = 'mobile-menu-toggle';
    mobileMenuToggle.innerHTML = '<i class="fas fa-bars"></i>';
    mobileMenuToggle.setAttribute('aria-label', 'فتح القائمة');
    
    const headerActions = document.querySelector('.header-actions');
    if (headerActions) {
        headerActions.insertBefore(mobileMenuToggle, headerActions.firstChild);
    }
    
    mobileMenuToggle.addEventListener('click', function() {
        const nav = document.querySelector('.nav');
        nav.classList.toggle('active');
        
        // Toggle icon
        const icon = this.querySelector('i');
        if (nav.classList.contains('active')) {
            icon.classList.remove('fa-bars');
            icon.classList.add('fa-times');
        } else {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }
    });
}

// Add these functions to the initializeEventListeners function
function initializeEventListeners() {
    // Cart toggle
    cartIcon.addEventListener('click', toggleCart);
    closeCart.addEventListener('click', closeCartSidebar);
    overlay.addEventListener('click', closeCartSidebar);
    
    // Add to cart buttons
    document.querySelectorAll('.btn-add-cart').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productCard = this.closest('.product-card');
            const product = getProductFromCard(productCard);
            addToCart(product);
        });
    });
    
    // Wishlist buttons
    document.querySelectorAll('.btn-wishlist').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const productCard = this.closest('.product-card');
            const product = getProductFromCard(productCard);
            toggleWishlist(product, this);
        });
    });
    
    // Newsletter form
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            showToast('تم اشتراكك بنجاح! شكراً لك.', 'success');
            this.reset();
        });
    }
    
    // Search functionality
    const searchInput = document.querySelector('.search-box input');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            filterProducts(searchTerm);
        });
    }
    
    // Category cards
    document.querySelectorAll('.category-card').forEach(card => {
        card.addEventListener('click', function() {
            const category = this.querySelector('h3').textContent;
            scrollToCategory(category);
        });
    });
    
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Scroll animations
    window.addEventListener('scroll', handleScroll);
    
    // Initialize new features
    initializeScrollToTop();
    initializeMobileMenu();
}

// Cart Functions
function toggleCart() {
    cartSidebar.classList.toggle('active');
    overlay.classList.toggle('active');
    document.body.style.overflow = cartSidebar.classList.contains('active') ? 'hidden' : '';
}

function closeCartSidebar() {
    cartSidebar.classList.remove('active');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
}

function getProductFromCard(productCard) {
    const name = productCard.querySelector('h3').textContent;
    const priceText = productCard.querySelector('.price').textContent;
    const price = parseFloat(priceText.replace(/[^0-9.]/g, ''));
    const image = productCard.querySelector('img').src;
    const description = productCard.querySelector('p').textContent;
    
    return {
        id: Date.now(),
        name,
        price,
        image,
        description,
        quantity: 1
    };
}

function addToCart(product) {
    const existingItem = cart.find(item => item.name === product.name);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push(product);
    }
    
    updateCartUI();
    saveCartToStorage();
    showToast(`تم إضافة ${product.name} إلى السلة`, 'success');
    
    // Animate cart icon
    cartIcon.style.transform = 'scale(1.2)';
    setTimeout(() => {
        cartIcon.style.transform = 'scale(1)';
    }, 200);
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartUI();
    saveCartToStorage();
    showToast('تم حذف المنتج من السلة', 'success');
}

function updateQuantity(productId, change) {
    const item = cart.find(item => item.id === productId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            removeFromCart(productId);
        } else {
            updateCartUI();
            saveCartToStorage();
        }
    }
}

function updateCartUI() {
    // Update cart count
    cartCount = cart.reduce((total, item) => total + item.quantity, 0);
    cartCountElement.textContent = cartCount;
    
    // Update cart items
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div style="text-align: center; padding: 2rem;">
                <i class="fas fa-shopping-cart" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>
                <p style="color: #999;">السلة فارغة</p>
            </div>
        `;
    } else {
        cartItemsContainer.innerHTML = cart.map(item => `
            <div class="cart-item">
                <img src="${item.image}" alt="${item.name}">
                <div class="cart-item-info">
                    <h4>${item.name}</h4>
                    <div class="cart-item-price">${item.price} ريال</div>
                    <div class="cart-item-quantity">
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
                    </div>
                </div>
                <button class="remove-item" onclick="removeFromCart(${item.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `).join('');
    }
    
    // Update total price
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    totalPriceElement.textContent = `${total.toFixed(2)} ريال`;
}

// Wishlist Functions
function toggleWishlist(product, button) {
    const index = wishlist.findIndex(item => item.name === product.name);
    
    if (index === -1) {
        wishlist.push(product);
        button.querySelector('i').classList.remove('far');
        button.querySelector('i').classList.add('fas');
        button.style.background = '#ff6b6b';
        button.style.color = 'white';
        showToast(`تم إضافة ${product.name} إلى المفضلة`, 'success');
    } else {
        wishlist.splice(index, 1);
        button.querySelector('i').classList.remove('fas');
        button.querySelector('i').classList.add('far');
        button.style.background = 'white';
        button.style.color = '';
        showToast(`تم حذف ${product.name} من المفضلة`, 'success');
    }
}

// Product Filtering
function filterProducts(searchTerm) {
    const products = document.querySelectorAll('.product-card');
    let visibleCount = 0;
    
    products.forEach(product => {
        const name = product.querySelector('h3').textContent.toLowerCase();
        const description = product.querySelector('p').textContent.toLowerCase();
        
        if (name.includes(searchTerm) || description.includes(searchTerm)) {
            product.style.display = 'block';
            visibleCount++;
        } else {
            product.style.display = 'none';
        }
    });
    
    if (visibleCount === 0 && searchTerm) {
        showToast('لا توجد نتائج للبحث', 'error');
    }
}

function scrollToCategory(category) {
    // Map category names to section IDs
    const categoryMap = {
        'إلكترونيات': 'electronics-section',
        'ملابس': 'fashion-section', 
        'أثاث': 'furniture-section',
        'كتب': 'books-section'
    };
    
    const sectionId = categoryMap[category];
    if (sectionId) {
        // First, scroll to the products section
        const productsSection = document.querySelector('#products');
        if (productsSection) {
            productsSection.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
        
        // Then, find and highlight the specific category section
        setTimeout(() => {
            const targetSection = document.querySelector(`#${sectionId}`);
            if (targetSection) {
                // Add highlight effect
                targetSection.style.transition = 'all 0.3s ease';
                targetSection.style.transform = 'scale(1.02)';
                targetSection.style.boxShadow = '0 15px 40px rgba(52, 152, 219, 0.2)';
                targetSection.style.background = 'linear-gradient(135deg, rgba(52, 152, 219, 0.05) 0%, rgba(41, 128, 185, 0.05) 100%)';
                targetSection.style.borderRadius = '15px';
                targetSection.style.padding = '20px';
                targetSection.style.margin = '-20px';
                
                // Scroll to the specific section
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'center'
                });
                
                // Remove highlight after animation
                setTimeout(() => {
                    targetSection.style.transform = 'scale(1)';
                    targetSection.style.boxShadow = '';
                    targetSection.style.background = '';
                    targetSection.style.borderRadius = '';
                    targetSection.style.padding = '';
                    targetSection.style.margin = '';
                }, 2000);
            }
        }, 500);
        
        showToast(`عرض قسم ${category}`, 'success');
    }
}

function filterByCategory(category) {
    // This would typically filter products by category
    // For now, we'll just scroll to products section
    const productsSection = document.querySelector('#products');
    if (productsSection) {
        productsSection.scrollIntoView({ behavior: 'smooth' });
        showToast(`عرض منتجات قسم ${category}`, 'success');
    }
}

// Storage Functions
function saveCartToStorage() {
    localStorage.setItem('cart', JSON.stringify(cart));
}

function loadCartFromStorage() {
    const savedCart = localStorage.getItem('cart');
    if (savedCart) {
        cart = JSON.parse(savedCart);
    }
}

// Toast Notifications
function showToast(message, type = 'success') {
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 3000);
}

// Scroll Animations
function handleScroll() {
    const header = document.querySelector('.header');
    if (window.scrollY > 100) {
        header.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        header.style.boxShadow = '0 5px 20px rgba(0,0,0,0.2)';
    } else {
        header.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        header.style.boxShadow = '0 2px 10px rgba(0,0,0,0.1)';
    }
    
    // Animate elements on scroll
    animateOnScroll();
}

function initializeAnimations() {
    // Add animation classes to elements
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe product cards and category cards
    document.querySelectorAll('.product-card, .category-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });
}

function animateOnScroll() {
    const scrolled = window.pageYOffset;
    const parallax = document.querySelector('.hero');
    if (parallax) {
        parallax.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
}

// Checkout functionality
document.querySelector('.btn-checkout')?.addEventListener('click', function() {
    if (cart.length === 0) {
        showToast('السلة فارغة! أضف منتجات أولاً', 'error');
        return;
    }
    
    // In a real application, this would redirect to a checkout page
    showToast('جاري الانتقال إلى صفحة الدفع...', 'success');
    setTimeout(() => {
        // Simulate checkout process
        const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        showToast(`تم إتمام الشراء بنجاح! المجموع: ${total.toFixed(2)} ريال`, 'success');
        cart = [];
        updateCartUI();
        saveCartToStorage();
        closeCartSidebar();
    }, 2000);
});

// Product detail modal (for future enhancement)
function showProductDetails(product) {
    // This would show a modal with detailed product information
    console.log('Product details:', product);
}

// Initialize lazy loading for images
function initializeLazyLoading() {
    const images = document.querySelectorAll('img[data-src]');
    const imageObserver = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                imageObserver.unobserve(img);
            }
        });
    });
    
    images.forEach(img => imageObserver.observe(img));
}

// Performance optimization
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debounce to search
const searchInput = document.querySelector('.search-box input');
if (searchInput) {
    searchInput.addEventListener('input', debounce(function(e) {
        filterProducts(e.target.value.toLowerCase());
    }, 300));
}

// Theme toggle (for future enhancement)
function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const isDark = document.body.classList.contains('dark-theme');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
}

// Load saved theme
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    document.body.classList.add('dark-theme');
}

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl/Cmd + K to focus search
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        document.querySelector('.search-box input')?.focus();
    }
    
    // Escape to close cart
    if (e.key === 'Escape' && cartSidebar.classList.contains('active')) {
        closeCartSidebar();
    }
});

// Print functionality
function printCart() {
    window.print();
}

// Share functionality
function shareProduct(product) {
    if (navigator.share) {
        navigator.share({
            title: product.name,
            text: product.description,
            url: window.location.href
        });
    } else {
        // Fallback for browsers that don't support Web Share API
        const url = window.location.href;
        navigator.clipboard.writeText(url);
        showToast('تم نسخ الرابط', 'success');
    }
}

// Initialize everything when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    initializeLazyLoading();
    console.log('المتجر الإلكتروني جاهز للاستخدام!');
});
