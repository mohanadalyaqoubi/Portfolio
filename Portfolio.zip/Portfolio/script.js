// Portfolio Data
const portfolioData = [
    {
        id: 1,
        title: "متجر إلكتروني عصري",
        description: "منصة تجارة إلكترونية سريعة وتفاعلية",
        image: "https://picsum.photos/seed/ecommerce/400/300.webp"
    },
    {
        id: 2,
        title: "تطبيق موبايل احترافي",
        description: "واجهة مستخدم سلسة وتجربة استخدام استثنائية",
        image: "https://picsum.photos/seed/mobileapp/400/300.webp"
    },
    {
        id: 3,
        title: "موقع تعليمي تفاعلي",
        description: "منصة تعليمية حديثة مع أدوات تفاعلية",
        image: "https://picsum.photos/seed/education/400/300.webp"
    },
    {
        id: 4,
        title: "لوحة تحكم إدارية",
        description: "نظام إدارة متكامل مع واجهة بسيطة",
        image: "https://picsum.photos/seed/dashboard/400/300.webp"
    },
    {
        id: 5,
        title: "موقع أعمال تجارية",
        description: "موقع احترافي للشركات الناشئة",
        image: "https://picsum.photos/seed/business/400/300.webp"
    },
    {
        id: 6,
        title: "منصة تواصل اجتماعي",
        description: "شبكة اجتماعية عصرية ومبتكرة",
        image: "https://picsum.photos/seed/social/400/300.webp"
    }
];

// Personal Projects Data
const myProjectsData = [
    {
        id: 1,
        title: "Royal Cafe - القائمة الملكية",
        description: "قائمة كافيه احترافية بتصميم ملكي فاخر مع نظام فلترة وتفاعل سلس",
        image: "./images/royal-cafe-preview.svg",
        category: "web",
        status: "completed",
        technologies: ["HTML5", "CSS3", "JavaScript", "Font Awesome", "AOS Library"],
        liveUrl: "./projects/cafe-menu-shop/index.html",
        githubUrl: null,
        details: {
            overview: "قائمة كافيه احترافية بتصميم ملكي فاخر، تتميز بالألوان الذهبية والتصميم الأنيق مع نظام فلترة متقدم للمنتجات وتفاعلات سلسة.",
            features: ["قائمة منتجات تفاعلية", "نظام فلترة حسب الفئات", "تصميم متجاوب", "أنيميشن احترافي", "شاشة تحميل أنيقة", "تأثيرات بصرية متقدمة"],
            duration: "أسبوعين",
            team: "مشروع شخصي",
            challenges: "تحقيق التوازن بين التصميم الفاخر والأداء السريع مع الحفاظ على تجربة مستخدم سلسة"
        }
    },
    {
        id: 2,
        title: "MedVibe - النظام الطبي المتكامل",
        description: "نظام حجز طبي ذكي مع واجهة مستخدم ولوحة تحكم متكاملة لإدارة الحجوزات والأطباء",
        image: "./images/medvibe-preview.svg",
        category: "web",
        status: "completed",
        technologies: ["HTML5", "CSS3", "JavaScript", "Firebase", "Font Awesome", "Cairo Font"],
        liveUrl: "./projects/medical-booking-system/user-interface/index.html",
        adminUrl: "./projects/medical-booking-system/admin-dashboard/admin-dashboard.html",
        githubUrl: null,
        details: {
            overview: "نظام طبي متكامل يوفر حجز مواعيد الأطباء بذكاء، مع لوحة تحكم متقدمة لإدارة الحجوزات والأطباء والمرضى. النظام يحتوي على واجهتين: واجهة المستخدمين للحجز وواجهة الإدارة للتحكم الكامل بالنظام.",
            features: ["حجز مواعيد ذكي", "بحث عن الأطباء والتخصصات", "نظام تقويم متقدم", "إدارة الأطباء والمرضى", "إحصائيات وتقارير مفصلة", "نظام إشعارات فوري", "تعدد المستخدمين والأدوار", "أمان وحماية البيانات"],
            duration: "شهر",
            team: "مشروع شخصي",
            challenges: "بناء نظام متكامل مع واجهتين مختلفتين، ضمان أمان البيانات الطبية، وتحقيق تجربة مستخدم سلسة لكلا الواجهتين"
        }
    },
    {
        id: 3,
        title: "آلة حاسبة ذكية",
        description: "آلة حاسبة متقدمة مع واجهة أنيقة، سجل حسابات، ودعم العمليات العلمية",
        image: "./images/calculator-preview.svg",
        category: "web",
        status: "completed",
        technologies: ["HTML5", "CSS3", "JavaScript", "Font Awesome", "LocalStorage"],
        liveUrl: "./projects/calculator-app/index.html",
        githubUrl: null,
        details: {
            overview: "آلة حاسبة احترافية بتصميم عصري وأنيق، تدعم العمليات الحسابية الأساسية والعلمية مع نظام سجل للحفاظ على تاريخ العمليات.",
            features: ["عمليات حسابية أساسية", "عمليات علمية متقدمة", "سجل العمليات السابقة", "واجهة مستخدم تفاعلية", "دعم لوحة المفاتيح", "تصميم متجاوب", "تأثيرات بصرية سلسة", "حفظ البيانات محلياً"],
            duration: "أسبوع",
            team: "مشروع شخصي",
            challenges: "تحقيق التوازن بين الوظائف المتقدمة وسهولة الاستخدام مع الحفاظ على أداء سريع"
        }
    },
    {
        id: 4,
        title: "متجر إلكتروني متقدم",
        description: "منصة تجارة إلكترونية كاملة مع نظام دفع متكامل",
        image: "./images/ecommerce-preview.svg",
        category: "web",
        status: "completed",
        technologies: ["HTML5", "CSS3", "JavaScript", "Font Awesome"],
        liveUrl: "./متجر الكتروني/index.html",
        githubUrl: null,
        details: {
            overview: "متجر إلكتروني حديث يوفر تجربة تسوق ممتازة للمستخدمين مع نظام دفع آمن وواجهة إدارية متكاملة.",
            features: ["سلة تسوق متقدمة", "نظام دفع آمن", "فلترة المنتجات", "صفحات منتجات تفاعلية", "نظام اتصال", "تصميم متجاوب"],
            duration: "أسبوعين",
            team: "مشروع شخصي",
            challenges: "بناء متجر إلكتروني متكامل مع جميع الوظائف الأساسية للتجارة الإلكترونية"
        }
    },
    {
        id: 5,
        title: "تطبيق مهام ذكي",
        description: "تطبيق إدارة مهام مع ذكاء اصطناعي لتنظيم الأولويات",
        image: "https://picsum.photos/seed/myproject2/400/300.webp",
        category: "app",
        status: "in-progress",
        technologies: ["React Native", "Firebase", "AI/ML"],
        liveUrl: "https://example.com",
        githubUrl: "https://github.com/example",
        details: {
            overview: "تطبيق ذكي لإدارة المهام يستخدم الذكاء الاصطناعي لتنظيم الأولويات وتحسين الإنتاجية.",
            features: ["تنظيم تلقائي للمهام", "تحليل الإنتاجية", "تذكيرات ذكية", "تقارير متقدمة"],
            duration: "جاري العمل",
            team: "مشروع شخصي",
            challenges: "دمج خوارزميات الذكاء الاصطناعي مع واجهة سهلة الاستخدام"
        }
    },
    {
        id: 6,
        title: "موقع تعليمي تفاعلي",
        description: "منصة تعليمية مع دروس تفاعلية ونظام تقييم",
        image: "https://picsum.photos/seed/myproject3/400/300.webp",
        category: "web",
        status: "completed",
        technologies: ["Vue.js", "Express", "PostgreSQL", "WebRTC"],
        liveUrl: "https://example.com",
        githubUrl: "https://github.com/example",
        details: {
            overview: "منصة تعليمية حديثة توفر دروس تفاعلية وفصول دراسية افتراضية مع نظام تقييم متقدم.",
            features: ["فصول دراسية افتراضية", "نظام تقييم تلقائي", "تتبع التقدم", "محتوى تفاعلي"],
            duration: "4 أشهر",
            team: "فريق من 5 مطورين",
            challenges: "ضمان استقرار البث المباشر وجودة الفيديو"
        }
    },
    {
        id: 7,
        title: "لوحة تحكم إحصائيات",
        description: "نظام تحليل بيانات متقدم مع رسوم بيانية تفاعلية",
        image: "https://picsum.photos/seed/myproject4/400/300.webp",
        category: "design",
        status: "planning",
        technologies: ["D3.js", "Python", "FastAPI", "Redis"],
        liveUrl: null,
        githubUrl: null,
        details: {
            overview: "لوحة تحكم متقدمة لعرض وتحليل البيانات مع رسوم بيانية تفاعلية وتقارير مخصصة.",
            features: ["رسوم بيانية تفاعلية", "تحليل فوري", "تقارير مخصصة", "تنبيهات ذكية"],
            duration: "مخطط لمدة شهرين",
            team: "مشروع شخصي",
            challenges: "معالجة كميات كبيرة من البيانات في الوقت الفعلي"
        }
    }
];

// DOM Elements
const changingText = document.getElementById('changingText');
const darkModeToggle = document.getElementById('darkModeToggle');
const portfolioGrid = document.getElementById('portfolioGrid');
const contactForm = document.getElementById('contactForm');
const submitBtn = document.getElementById('submitBtn');
const myProjectsGrid = document.getElementById('myProjectsGrid');
const projectModal = document.getElementById('projectModal');
const modalClose = document.getElementById('modalClose');
const modalBody = document.getElementById('modalBody');
const addProjectBtn = document.getElementById('addProjectBtn');

// Text Animation
const words = ['سريعة', 'ذكية', 'بسيطة', 'احترافية', 'مبتكرة'];
let wordIndex = 0;

function changeText() {
    wordIndex = (wordIndex + 1) % words.length;
    changingText.textContent = words[wordIndex];
}

setInterval(changeText, 2000);

// Dark Mode Toggle
darkModeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
});

// Load saved theme
const savedTheme = localStorage.getItem('theme') || 'dark';
document.documentElement.setAttribute('data-theme', savedTheme);

// Smooth Scroll for Navigation
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href').substring(1);
        const targetSection = document.getElementById(targetId);
        
        if (targetSection) {
            targetSection.scrollIntoView({ behavior: 'smooth' });
        }
    });
});

// Load My Projects
function loadMyProjects() {
    myProjectsGrid.innerHTML = '';
    
    myProjectsData.forEach((project, index) => {
        const projectCard = document.createElement('div');
        projectCard.className = `my-project-card animate-on-scroll ${project.category}`;
        projectCard.dataset.projectId = project.id;
        
        projectCard.innerHTML = `
            <div class="project-status status-${project.status}">
                ${getStatusText(project.status)}
            </div>
            <img src="${project.image}" alt="${project.title}" class="project-image" loading="lazy">
            <div class="project-content">
                <h3 class="project-title">${project.title}</h3>
                <p class="project-description">${project.description}</p>
                <div class="project-tech">
                    ${project.technologies.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
                </div>
                <div class="project-links">
                    ${project.liveUrl ? `
                        <a href="${project.liveUrl}" target="_blank" class="project-link" onclick="event.stopPropagation()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                                <polyline points="15,3 21,3 21,9"></polyline>
                                <line x1="10" y1="14" x2="21" y2="3"></line>
                            </svg>
                            معاينة
                        </a>
                    ` : ''}
                    ${project.githubUrl ? `
                        <a href="${project.githubUrl}" target="_blank" class="project-link" onclick="event.stopPropagation()">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>
                            </svg>
                            GitHub
                        </a>
                    ` : ''}
                </div>
            </div>
        `;
        
        projectCard.addEventListener('click', () => openProjectModal(project));
        myProjectsGrid.appendChild(projectCard);
        
        // Trigger animation with delay
        setTimeout(() => {
            projectCard.classList.add('loaded');
        }, index * 100);
    });
}

function getStatusText(status) {
    const statusMap = {
        'completed': 'مكتمل',
        'in-progress': 'قيد التنفيذ',
        'planning': 'قيد التخطيط'
    };
    return statusMap[status] || status;
}

// Project Modal
function openProjectModal(project) {
    modalBody.innerHTML = `
        <img src="${project.image}" alt="${project.title}" class="modal-project-image">
        
        <div class="modal-project-info">
            <h4>نظرة عامة</h4>
            <p>${project.details.overview}</p>
        </div>
        
        <div class="modal-project-details">
            <div class="detail-item">
                <div class="detail-label">المدة</div>
                <div class="detail-value">${project.details.duration}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">الفريق</div>
                <div class="detail-value">${project.details.team}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">الحالة</div>
                <div class="detail-value">${getStatusText(project.status)}</div>
            </div>
            <div class="detail-item">
                <div class="detail-label">الفئة</div>
                <div class="detail-value">${getCategoryText(project.category)}</div>
            </div>
        </div>
        
        <div class="modal-project-info">
            <h4>المميزات الرئيسية</h4>
            <ul style="color: var(--text-secondary); line-height: 1.8;">
                ${project.details.features.map(feature => `<li>${feature}</li>`).join('')}
            </ul>
        </div>
        
        <div class="modal-project-info">
            <h4>التحديات</h4>
            <p>${project.details.challenges}</p>
        </div>
        
        <div class="modal-project-info">
            <h4>التقنيات المستخدمة</h4>
            <div class="project-tech">
                ${project.technologies.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
            </div>
        </div>
        
        <div class="modal-actions">
            ${project.liveUrl ? `
                <a href="${project.liveUrl}" target="_blank" class="modal-btn modal-btn-primary">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                        <polyline points="15,3 21,3 21,9"></polyline>
                        <line x1="10" y1="14" x2="21" y2="3"></line>
                    </svg>
                    معاينة المستخدم
                </a>
            ` : ''}
            ${project.githubUrl ? `
                <a href="${project.githubUrl}" target="_blank" class="modal-btn modal-btn-secondary">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 0 0-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0 0 20 4.77 5.07 5.07 0 0 0 19.91 1S18.73.65 16 2.48a13.38 13.38 0 0 0-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 0 0 5 4.77a5.44 5.44 0 0 0-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 0 0 9 18.13V22"></path>
                    </svg>
                    عرض الكود
                </a>
            ` : ''}
        </div>
    `;
    
    projectModal.classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeProjectModal() {
    projectModal.classList.remove('active');
    document.body.style.overflow = '';
}

function getCategoryText(category) {
    const categoryMap = {
        'web': 'مواقع ويب',
        'app': 'تطبيقات',
        'design': 'تصميم'
    };
    return categoryMap[category] || category;
}

// Project Filters
function setupProjectFilters() {
    const filterButtons = document.querySelectorAll('.filter-btn');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', () => {
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            
            // Filter projects
            const filter = button.dataset.filter;
            const projectCards = document.querySelectorAll('.my-project-card');
            
            projectCards.forEach(card => {
                if (filter === 'all' || card.classList.contains(filter)) {
                    card.classList.remove('hidden');
                } else {
                    card.classList.add('hidden');
                }
            });
        });
    });
}

// Add Project Functionality
addProjectBtn.addEventListener('click', () => {
    const newProject = {
        id: myProjectsData.length + 1,
        title: "مشروع جديد",
        description: "أضف وصف مشروعك هنا",
        image: `https://picsum.photos/seed/newproject${Date.now()}/400/300.webp`,
        category: "web",
        status: "planning",
        technologies: ["HTML", "CSS", "JavaScript"],
        liveUrl: null,
        githubUrl: null,
        details: {
            overview: "وصف المشروع الجديد الذي تعمل عليه.",
            features: ["ميزة 1", "ميزة 2", "ميزة 3"],
            duration: "قيد التخطيط",
            team: "مشروع شخصي",
            challenges: "التحديات التي تواجهها في المشروع"
        }
    };
    
    myProjectsData.push(newProject);
    loadMyProjects();
    
    // Scroll to the new project
    setTimeout(() => {
        const newCard = document.querySelector(`[data-project-id="${newProject.id}"]`);
        if (newCard) {
            newCard.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }, 100);
});

// Modal Event Listeners
modalClose.addEventListener('click', closeProjectModal);
projectModal.addEventListener('click', (e) => {
    if (e.target === projectModal) {
        closeProjectModal();
    }
});

// Escape key to close modal
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && projectModal.classList.contains('active')) {
        closeProjectModal();
    }
});

// Lazy Loading for Portfolio
function loadPortfolioItems() {
    portfolioData.forEach((item, index) => {
        const portfolioItem = document.createElement('div');
        portfolioItem.className = 'portfolio-item';
        portfolioItem.innerHTML = `
            <img src="${item.image}" alt="${item.title}" class="portfolio-image" loading="lazy">
            <div class="portfolio-overlay">
                <h3 class="portfolio-title">${item.title}</h3>
                <p class="portfolio-description">${item.description}</p>
            </div>
        `;
        
        portfolioGrid.appendChild(portfolioItem);
        
        // Trigger animation with delay
        setTimeout(() => {
            portfolioItem.classList.add('loaded');
        }, index * 100);
    });
}

// Intersection Observer for Animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-on-scroll');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe feature cards
document.addEventListener('DOMContentLoaded', () => {
    const featureCards = document.querySelectorAll('.feature-card');
    featureCards.forEach(card => {
        observer.observe(card);
    });
    
    // Load portfolio items
    loadPortfolioItems();
    
    // Load my projects
    loadMyProjects();
    
    // Setup project filters
    setupProjectFilters();
    
    // Observe portfolio items for lazy loading
    const portfolioItems = document.querySelectorAll('.portfolio-item img');
    const imageObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src || img.src;
                img.classList.add('loaded');
                imageObserver.unobserve(img);
            }
        });
    }, observerOptions);
    
    portfolioItems.forEach(img => {
        imageObserver.observe(img);
    });
});

// Contact Form Handling
contactForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(contactForm);
    const data = Object.fromEntries(formData);
    
    // Show loading state
    const originalText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<div class="loading"></div>';
    submitBtn.disabled = true;
    
    // Simulate form submission
    setTimeout(() => {
        // Show success state
        submitBtn.classList.add('success');
        submitBtn.innerHTML = `
            <span class="btn-text">تم الإرسال بنجاح!</span>
            <svg class="check-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
        `;
        
        // Reset form
        contactForm.reset();
        
        // Reset button after 3 seconds
        setTimeout(() => {
            submitBtn.classList.remove('success');
            submitBtn.innerHTML = originalText;
            submitBtn.disabled = false;
        }, 3000);
    }, 1500);
});

// Navbar scroll effect
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        navbar.style.background = 'rgba(10, 10, 10, 0.95)';
        navbar.style.backdropFilter = 'blur(20px)';
    } else {
        navbar.style.background = 'var(--glass-bg)';
        navbar.style.backdropFilter = 'blur(10px)';
    }
    
    lastScroll = currentScroll;
});

// Add parallax effect to hero section
window.addEventListener('scroll', () => {
    const scrolled = window.pageYOffset;
    const heroGradient = document.querySelector('.hero-gradient');
    
    if (heroGradient) {
        heroGradient.style.transform = `translateY(${scrolled * 0.5}px)`;
    }
});

// Performance optimization - Debounce scroll events
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Apply debounce to scroll events
const debouncedScroll = debounce(() => {
    // Scroll-based animations
}, 10);

window.addEventListener('scroll', debouncedScroll);

// Add keyboard navigation
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        // Close any open modals or reset forms
        contactForm.reset();
    }
});

// Performance monitoring
if ('performance' in window) {
    window.addEventListener('load', () => {
        const perfData = performance.getEntriesByType('navigation')[0];
        console.log('Page load time:', perfData.loadEventEnd - perfData.loadEventStart, 'ms');
    });
}

// Service Worker Registration (for PWA support)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
}
